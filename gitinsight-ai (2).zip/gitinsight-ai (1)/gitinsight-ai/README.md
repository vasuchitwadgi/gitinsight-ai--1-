# GitInsight AI

An AI-powered project analyzer and interview coach for developers/students. Point it at a
public GitHub repo, upload a project ZIP, and/or describe your project — get a review that
combines **real measured metrics** with an AI narrative: a scored readiness breakdown, an
improvement roadmap, resume-ready descriptions, and project-specific interview questions.

## What's "advanced" here

- **Two AI providers, picked per analysis:** Claude (Anthropic) or Gemini (Google) — set both
  API keys and switch per request from the UI, or set a default via `AI_PROVIDER`.
- **Real file-tree metrics**, not AI guesses: for GitHub repos, pulls the full recursive tree via
  the Git Trees API; for uploads, extracts the ZIP server-side. Computes actual total file count,
  file-type breakdown, test-file count, and whether a README / `.gitignore` / lockfile / committed
  `.env` exist.
- **Live dependency freshness check**: reads `package.json` and checks each dependency's current
  vs. latest version against the public npm registry.
- **Regex-based secret scanning**: flags likely AWS keys, hardcoded passwords, private-key blocks,
  and credential-bearing connection strings in common risky filenames (`.env`, `config.js`, etc.).
- **ZIP upload** as an alternative to a GitHub URL, so private/local projects work too.
- **Project comparison**: select 2–3 analyzed projects and see their scores, measured metrics,
  and tech stacks side by side.
- The AI is explicitly instructed to use the *real* numbers above where they exist, and to give
  clearly-labeled qualitative estimates (never fabricated precise numbers) everywhere else.

## Stack

- **Backend:** Node.js, Express, MongoDB (Mongoose), JWT auth, GitHub REST API, Multer + AdmZip
  for uploads, npm registry checks, Claude and Gemini SDKs behind a provider switch.
- **Frontend:** React (Vite), React Router, Tailwind (CDN).

## Project structure

```
gitinsight-ai/
  backend/
    src/
      config/db.js
      models/           User, Project, Analysis (now with metrics/dependencyReport/secretFindings)
      middleware/auth.js
      routes/            auth.routes.js, project.routes.js (+ /compare, ZIP upload)
      controllers/       auth.controller.js, project.controller.js (orchestrates everything)
      services/
        github.service.js       repo metadata + full recursive file tree + file content
        zip.service.js          ZIP extraction (adm-zip)
        staticAnalysis.service.js   real metrics from a file list + secret regex scan
        npm.service.js          live dependency freshness vs npm registry
        ai/
          prompt.js              shared prompt builder
          claude.provider.js     Anthropic implementation
          gemini.provider.js     Google Gemini implementation
          index.js               provider dispatcher (env default or per-request override)
  frontend/
    src/pages/           Login, Register, Dashboard, Analyze, Results, Compare
```

## 1. Backend setup

```bash
cd backend
cp .env.example .env
npm install
npm run dev        # http://localhost:5000
```

Fill in `.env`:
- `MONGO_URI` — local `mongod` or a free MongoDB Atlas cluster
- `JWT_SECRET` — any long random string
- `AI_PROVIDER` — `anthropic` or `gemini` (default when a request doesn't specify one)
- `ANTHROPIC_API_KEY` — from https://console.anthropic.com (needed to use Claude)
- `GEMINI_API_KEY` — from https://aistudio.google.com/apikey (needed to use Gemini; it has a
  generous free tier, useful if you don't have an Anthropic key)
- `GITHUB_TOKEN` (optional) — a personal access token to raise the GitHub API rate limit,
  especially useful since analysis now pulls the full repo file tree

You only need **one** of the two AI provider keys to get started — the UI lets you pick which
provider to use per analysis, and the backend returns a clear error if the chosen provider's key
is missing.

## 2. Frontend setup

```bash
cd frontend
cp .env.example .env
npm install
npm run dev        # http://localhost:5173
```

Register an account, then on the "Analyze project" page: paste a GitHub URL and/or upload a ZIP
and/or type a description, pick Claude or Gemini, and submit.

## API overview

| Method | Route                     | Auth | Description |
|--------|----------------------------|------|--------------|
| POST   | /api/auth/register          | –    | Create an account |
| POST   | /api/auth/login             | –    | Log in, get a JWT |
| GET    | /api/auth/me                | ✓    | Current user |
| POST   | /api/projects/analyze       | ✓    | Multipart or JSON: `{ githubUrl?, manualText?, provider?, projectZip? }` |
| GET    | /api/projects               | ✓    | List your analyzed projects |
| GET    | /api/projects/:id           | ✓    | One project + its latest analysis |
| GET    | /api/projects/compare?ids=a,b[,c] | ✓ | Compare 2–3 of your projects |

## Notes & further ideas

- Dependency and secret checks are capped (25 deps, a handful of risky filenames, 200 files in a
  ZIP) to keep an analysis fast — raise the caps in `npm.service.js` / `project.controller.js` if
  you need deeper coverage.
- Secret scanning is regex-based and will have false positives/negatives — treat findings as
  leads to check manually, not proof.
- Natural next steps: run ESLint/ts-check on uploaded projects for real lint-based code-quality
  scores, queue long analyses with BullMQ instead of blocking the request, and add OSV/GitHub
  Advisory Database lookups for real vulnerability data instead of just version-freshness.

import { Router } from 'express';
import multer from 'multer';
import {
  analyze,
  listProjects,
  getProject,
  compareProjects,
  chatWithRepo,
  deleteProject,
  getProjectReport,
  saveProjectReport,
  regenerateProjectReport
} from '../controllers/project.controller.js';
import { requireAuth } from '../middleware/auth.js';

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 } // 25MB cap on uploaded project ZIPs
});

const router = Router();

router.use(requireAuth);
router.post('/analyze', upload.single('projectZip'), analyze);
router.get('/compare', compareProjects);
router.get('/', listProjects);
router.get('/:id', getProject);
router.delete('/:id', deleteProject);
router.post('/:id/chat', chatWithRepo);
router.get('/:id/report', getProjectReport);
router.post('/:id/report', saveProjectReport);
router.post('/:id/report/regenerate', regenerateProjectReport);

export default router;

import Project from '../models/Project.js';
import Analysis from '../models/Analysis.js';
import { parseGithubUrl, fetchRepoData, fetchRepoTree, fetchFileContent } from '../services/github.service.js';
import { extractZipEntries } from '../services/zip.service.js';
import { buildMetricsFromPaths, scanTextForSecrets } from '../services/staticAnalysis.service.js';
import { checkDependencyFreshness } from '../services/npm.service.js';
import { analyzeProject as runAiAnalysis, chatWithRepository } from '../services/ai/index.js';
import { buildDefaultStudentProjectReport } from '../services/ai/reportGenerator.js';
import { asyncHandler } from '../utils/asyncHandler.js';

const SECRET_SCAN_TARGETS = ['.env', 'config.js', 'config.json', 'settings.py', 'application.properties'];
const TOP_CODE_TARGETS = ['package.json', 'server.js', 'app.js', 'index.js', 'main.jsx', 'App.jsx', 'README.md'];

async function analyzeGithubSource(githubUrl) {
  const parsed = parseGithubUrl(githubUrl);
  if (!parsed) return { warning: "That doesn't look like a GitHub repo URL — continuing with the description only." };

  const repoMeta = await fetchRepoData(parsed.owner, parsed.repo);
  const paths = await fetchRepoTree(parsed.owner, parsed.repo, repoMeta.defaultBranch);
  const metrics = paths.length ? buildMetricsFromPaths(paths) : null;

  // Targeted secret scan: only fetch content of a handful of commonly-risky filenames actually present in the tree.
  const suspiciousPaths = paths.filter((p) => SECRET_SCAN_TARGETS.some((t) => p.toLowerCase().endsWith(t))).slice(0, 5);
  const secretFindings = [];
  for (const p of suspiciousPaths) {
    const content = await fetchFileContent(parsed.owner, parsed.repo, p);
    secretFindings.push(...scanTextForSecrets(p, content));
  }

  // Fetch top code files for deep review and architecture
  const files = [];
  const candidatePaths = paths.filter((p) => TOP_CODE_TARGETS.some((t) => p.toLowerCase().endsWith(t.toLowerCase()))).slice(0, 10);
  for (const p of candidatePaths) {
    const content = await fetchFileContent(parsed.owner, parsed.repo, p);
    if (content) files.push({ name: p, content: content.slice(0, 50000) });
  }

  // Real dependency freshness, if package.json exists in the tree.
  let dependencyReport = [];
  if (paths.includes('package.json')) {
    const pkgText = await fetchFileContent(parsed.owner, parsed.repo, 'package.json');
    try {
      const pkg = JSON.parse(pkgText || '{}');
      dependencyReport = await checkDependencyFreshness({ ...pkg.dependencies, ...pkg.devDependencies });
    } catch {
      /* invalid package.json, skip */
    }
  }

  return { repoMeta, metrics, secretFindings, dependencyReport, paths, files };
}

function analyzeZipSource(buffer) {
  const { paths, readText, textEntries } = extractZipEntries(buffer);
  const metrics = buildMetricsFromPaths(paths);

  const secretFindings = [];
  for (const entry of textEntries.slice(0, 200)) {
    secretFindings.push(...scanTextForSecrets(entry.entryName, entry.getData().toString('utf8')));
  }

  const files = textEntries.slice(0, 80).map((e) => ({
    name: e.entryName,
    content: e.getData().toString('utf8')
  }));

  const pkgPath = paths.find((p) => p === 'package.json' || p.endsWith('/package.json'));
  let pkgDependencies = null;
  if (pkgPath) {
    try {
      const pkg = JSON.parse(readText(pkgPath) || '{}');
      pkgDependencies = { ...pkg.dependencies, ...pkg.devDependencies };
    } catch {
      /* skip invalid json */
    }
  }

  return { metrics, secretFindings, pkgDependencies, paths, files };
}

export const analyze = asyncHandler(async (req, res) => {
  const { githubUrl, manualText, provider } = req.body;
  const zipFile = req.file;

  if (!githubUrl && !manualText && !zipFile) {
    return res.status(400).json({ message: 'Provide a GitHub URL, a project description, and/or a ZIP file.' });
  }

  let repoMeta = null;
  let metrics = null;
  let dependencyReport = [];
  let secretFindings = [];
  let paths = [];
  let files = [];
  let sourceType = 'manual';
  let fetchWarning = null;

  if (zipFile) {
    sourceType = 'zip';
    const zipResult = analyzeZipSource(zipFile.buffer);
    metrics = zipResult.metrics;
    secretFindings = zipResult.secretFindings;
    paths = zipResult.paths;
    files = zipResult.files;
    if (zipResult.pkgDependencies) {
      dependencyReport = await checkDependencyFreshness(zipResult.pkgDependencies);
    }
  } else if (githubUrl) {
    sourceType = 'github';
    try {
      const ghResult = await analyzeGithubSource(githubUrl);
      if (ghResult.warning) {
        fetchWarning = ghResult.warning;
        sourceType = 'manual';
      } else {
        ({ repoMeta, metrics, secretFindings, dependencyReport, paths, files } = ghResult);
      }
    } catch (err) {
      fetchWarning = `Could not fetch repo automatically (${err.message}).`;
      sourceType = 'manual';
    }
  }

  if (!repoMeta && !manualText && !metrics) {
    return res.status(422).json({ message: fetchWarning || 'No usable project information was provided.' });
  }

  const aiResult = await runAiAnalysis({
    repoMeta,
    manualText,
    metrics,
    dependencyReport,
    secretFindings,
    files
  }, provider);

  const project = await Project.create({
    owner: req.userId,
    name: aiResult.projectName || repoMeta?.name || (zipFile ? zipFile.originalname.replace(/\.zip$/i, '') : 'Untitled project'),
    sourceType,
    githubUrl: githubUrl || '',
    description: repoMeta?.description || manualText?.slice(0, 300) || '',
    techStack: aiResult.techStack || [],
    repoMeta,
    fileTree: paths.slice(0, 1000),
    fileSnippets: files.slice(0, 30)
  });

  const analysis = await Analysis.create({
    project: project._id,
    ...aiResult,
    provider: aiResult._provider || provider || 'gemini',
    metrics,
    dependencyReport,
    secretFindings,
    chatHistory: [
      {
        sender: 'assistant',
        text: `Hello! I have analyzed **${project.name}**. You can ask me anything about this repository's architecture, security, API endpoints, or how to add new features.`
      }
    ]
  });

  res.status(201).json({ project, analysis, warning: fetchWarning });
});

export const listProjects = asyncHandler(async (req, res) => {
  const projects = await Project.find({ owner: req.userId }).sort({ createdAt: -1 }).lean();
  const projectIds = projects.map((p) => p._id);
  const analyses = await Analysis.find({ project: { $in: projectIds } }).sort({ createdAt: -1 }).lean();

  const latestByProject = new Map();
  for (const a of analyses) {
    const key = String(a.project);
    if (!latestByProject.has(key)) latestByProject.set(key, a);
  }

  const result = projects.map((p) => ({ project: p, analysis: latestByProject.get(String(p._id)) || null }));
  res.json({ items: result });
});

export const getProject = asyncHandler(async (req, res) => {
  const project = await Project.findOne({ _id: req.params.id, owner: req.userId }).lean();
  if (!project) return res.status(404).json({ message: 'Project not found.' });

  const analysis = await Analysis.findOne({ project: project._id }).sort({ createdAt: -1 }).lean();
  res.json({ project, analysis });
});

export const deleteProject = asyncHandler(async (req, res) => {
  const project = await Project.findOneAndDelete({ _id: req.params.id, owner: req.userId });
  if (!project) return res.status(404).json({ message: 'Project not found.' });
  await Analysis.deleteMany({ project: project._id });
  res.json({ ok: true, message: 'Project deleted successfully.' });
});

export const compareProjects = asyncHandler(async (req, res) => {
  const ids = String(req.query.ids || '').split(',').map((s) => s.trim()).filter(Boolean).slice(0, 3);
  if (ids.length < 2) return res.status(400).json({ message: 'Provide at least 2 project ids to compare, e.g. ?ids=id1,id2' });

  const projects = await Project.find({ _id: { $in: ids }, owner: req.userId }).lean();
  const analyses = await Analysis.find({ project: { $in: projects.map((p) => p._id) } }).sort({ createdAt: -1 }).lean();

  const items = projects.map((project) => ({
    project,
    analysis: analyses.find((a) => String(a.project) === String(project._id)) || null
  }));

  res.json({ items });
});

export const chatWithRepo = asyncHandler(async (req, res) => {
  const { message } = req.body;
  if (!message || !message.trim()) return res.status(400).json({ message: 'Message is required.' });

  const project = await Project.findOne({ _id: req.params.id, owner: req.userId });
  if (!project) return res.status(404).json({ message: 'Project not found.' });

  const analysis = await Analysis.findOne({ project: project._id }).sort({ createdAt: -1 });
  if (!analysis) return res.status(404).json({ message: 'Analysis record not found.' });

  const reply = await chatWithRepository({
    project,
    analysis,
    message: message.trim(),
    history: analysis.chatHistory || []
  });

  analysis.chatHistory = analysis.chatHistory || [];
  analysis.chatHistory.push({ sender: 'user', text: message.trim() });
  analysis.chatHistory.push({ sender: 'assistant', text: reply });
  await analysis.save();

  res.json({ reply, chatHistory: analysis.chatHistory });
});

export const getProjectReport = asyncHandler(async (req, res) => {
  const project = await Project.findOne({ _id: req.params.id, owner: req.userId }).lean();
  if (!project) return res.status(404).json({ message: 'Project not found.' });

  const analysis = await Analysis.findOne({ project: project._id }).sort({ createdAt: -1 });
  if (!analysis) return res.status(404).json({ message: 'Analysis record not found.' });

  if (!analysis.projectReport) {
    analysis.projectReport = buildDefaultStudentProjectReport({ project, analysis });
    await analysis.save();
  }

  res.json({ ok: true, report: analysis.projectReport });
});

export const saveProjectReport = asyncHandler(async (req, res) => {
  const { report } = req.body;
  if (!report) return res.status(400).json({ message: 'Report data is required.' });

  const project = await Project.findOne({ _id: req.params.id, owner: req.userId });
  if (!project) return res.status(404).json({ message: 'Project not found.' });

  const analysis = await Analysis.findOne({ project: project._id }).sort({ createdAt: -1 });
  if (!analysis) return res.status(404).json({ message: 'Analysis record not found.' });

  analysis.projectReport = report;
  await analysis.save();

  res.json({ ok: true, message: 'Project report saved successfully.', report: analysis.projectReport });
});

export const regenerateProjectReport = asyncHandler(async (req, res) => {
  const { prompt, studentMeta } = req.body;

  const project = await Project.findOne({ _id: req.params.id, owner: req.userId });
  if (!project) return res.status(404).json({ message: 'Project not found.' });

  const analysis = await Analysis.findOne({ project: project._id }).sort({ createdAt: -1 });
  if (!analysis) return res.status(404).json({ message: 'Analysis record not found.' });

  // Generate fresh report
  const freshReport = buildDefaultStudentProjectReport({
    project,
    analysis,
    studentMeta: studentMeta || analysis.projectReport?.meta || {}
  });

  // If prompt is provided and Gemini API key is present, enhance via AI
  if (prompt && process.env.GEMINI_API_KEY) {
    try {
      const { GoogleGenerativeAI } = await import('@google/generative-ai');
      const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
      const model = genAI.getGenerativeModel({ model: process.env.GEMINI_MODEL || 'gemini-1.5-flash' });
      const promptText = `You are an academic computer science professor helping a final year engineering student polish their project report for university submission.
Project: ${project.name}
Tech Stack: ${(analysis.techStack || []).join(', ')}
Student Instructions: ${prompt}

Based on this, return an improved academic Abstract and Chapter 1 Problem Statement & Objectives.
Respond strictly in JSON format with keys: "abstract", "problemStatement", "objectives" (array of 5 strings).`;

      const result = await model.generateContent(promptText);
      const rawText = result.response.text();
      const jsonMatch = rawText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        if (parsed.abstract) freshReport.frontMatter.abstract = parsed.abstract;
        if (parsed.problemStatement) freshReport.chapter1_intro.problemStatement = parsed.problemStatement;
        if (Array.isArray(parsed.objectives)) freshReport.chapter1_intro.objectives = parsed.objectives;
      }
    } catch (e) {
      console.warn('AI enhancement fallback:', e.message);
    }
  }

  analysis.projectReport = freshReport;
  await analysis.save();

  res.json({ ok: true, message: 'Report regenerated successfully.', report: freshReport });
});


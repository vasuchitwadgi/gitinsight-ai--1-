import mongoose from 'mongoose';

const analysisSchema = new mongoose.Schema(
  {
    project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true, index: true },
    summary: { type: String, default: '' },
    techStack: { type: [String], default: [] },
    scores: {
      codeQuality: Number,
      security: Number,
      documentation: Number,
      testing: Number,
      architecture: Number
    },
    scoreNote: { type: String, default: '' },
    strengths: { type: [String], default: [] },
    issues: [
      { title: String, detail: String, severity: { type: String, enum: ['low', 'medium', 'high'] } }
    ],
    roadmap: [
      { phase: String, action: String }
    ],
    resume: {
      short: String,
      resume: String,
      linkedin: String
    },
    interviewQuestions: [
      { question: String, category: String, answerTips: [String] }
    ],
    provider: { type: String, default: 'gemini' },
    metrics: { type: mongoose.Schema.Types.Mixed, default: null },
    dependencyReport: { type: mongoose.Schema.Types.Mixed, default: [] },
    secretFindings: { type: mongoose.Schema.Types.Mixed, default: [] },
    codeReview: { type: mongoose.Schema.Types.Mixed, default: [] },
    securityAudit: { type: mongoose.Schema.Types.Mixed, default: {} },
    testSuite: { type: mongoose.Schema.Types.Mixed, default: {} },
    architecture: { type: mongoose.Schema.Types.Mixed, default: {} },
    refactoringPlan: { type: mongoose.Schema.Types.Mixed, default: [] },
    projectReport: { type: mongoose.Schema.Types.Mixed, default: null },
    chatHistory: [
      {
        sender: { type: String, enum: ['user', 'assistant'], required: true },
        text: { type: String, required: true },
        timestamp: { type: Date, default: Date.now }
      }
    ]
  },
  { timestamps: true }
);

export default mongoose.model('Analysis', analysisSchema);

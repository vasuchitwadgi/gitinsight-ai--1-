import mongoose from 'mongoose';

const projectSchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    name: { type: String, required: true },
    sourceType: { type: String, enum: ['github', 'manual', 'zip'], required: true },
    githubUrl: { type: String, default: '' },
    description: { type: String, default: '' },
    techStack: { type: [String], default: [] },
    repoMeta: { type: mongoose.Schema.Types.Mixed, default: null },
    fileTree: { type: [String], default: [] },
    fileSnippets: { type: mongoose.Schema.Types.Mixed, default: [] }
  },
  { timestamps: true }
);

export default mongoose.model('Project', projectSchema);

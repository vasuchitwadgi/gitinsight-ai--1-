import { GoogleGenerativeAI } from '@google/generative-ai';
import { buildAnalysisPrompt, extractJson } from './prompt.js';

export async function runGemini(inputs) {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY is not set on the server.');
  }
  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  const modelName = process.env.GEMINI_MODEL || 'gemini-3.1-flash-lite';
  const model = genAI.getGenerativeModel({
    model: modelName,
    generationConfig: { responseMimeType: 'application/json' }
  });

  const prompt = buildAnalysisPrompt(inputs);
  const result = await model.generateContent(prompt);
  const text = result.response.text();
  if (!text) throw new Error('Gemini response contained no text.');
  return extractJson(text);
}

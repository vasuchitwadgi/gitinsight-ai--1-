import Anthropic from '@anthropic-ai/sdk';
import { buildAnalysisPrompt, extractJson } from './prompt.js';

export async function runClaude(inputs) {
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error('ANTHROPIC_API_KEY is not set on the server.');
  }
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  const model = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5';
  const prompt = buildAnalysisPrompt(inputs);

  const response = await client.messages.create({
    model,
    max_tokens: 3000,
    messages: [{ role: 'user', content: prompt }]
  });

  const textBlock = response.content.find((b) => b.type === 'text');
  if (!textBlock) throw new Error('Claude response contained no text.');
  return extractJson(textBlock.text);
}

import { runClaude } from './claude.provider.js';
import { runGemini } from './gemini.provider.js';
import { buildCompleteAnalysis } from '../analyzerEngine.js';

const PROVIDERS = { anthropic: runClaude, claude: runClaude, gemini: runGemini };

// `requestedProvider` lets the frontend pick per-analysis; falls back to AI_PROVIDER env, then gemini.
export async function analyzeProject(inputs, requestedProvider) {
  const baseAnalysis = buildCompleteAnalysis(inputs);
  const key = (requestedProvider || process.env.AI_PROVIDER || 'gemini').toLowerCase();
  const runner = PROVIDERS[key] || runGemini;

  try {
    const aiResult = await runner(inputs);
    // Merge AI insights with measured deep analysis
    return {
      ...baseAnalysis,
      ...aiResult,
      // Retain deep structured features if AI returned partial fields
      scores: {
        ...baseAnalysis.scores,
        ...(aiResult.scores || {})
      },
      architecture: aiResult.architecture || baseAnalysis.architecture,
      securityAudit: aiResult.securityAudit || baseAnalysis.securityAudit,
      codeReview: aiResult.codeReview || baseAnalysis.codeReview,
      testSuite: aiResult.testSuite || baseAnalysis.testSuite,
      refactoringPlan: aiResult.refactoringPlan || baseAnalysis.refactoringPlan,
      _provider: key === 'claude' ? 'anthropic' : key,
      _aiEnhanced: true
    };
  } catch (err) {
    console.warn(`[GitInsight AI] ${key} provider had a temporary issue (${err.message}). Seamlessly activated Smart Offline Analysis Engine.`);
    return {
      ...baseAnalysis,
      _provider: `${key} (fallback)`,
      _aiEnhanced: false,
      _fallbackNotice: `Analysis generated using Smart Static & AST Engine (${err.message.slice(0, 100)})`
    };
  }
}

// Grounded Repository Chat
export async function chatWithRepository({ project, analysis, message, history = [] }) {
  const query = message.toLowerCase().trim();
  const fileTree = project.fileTree || [];
  const fileSnippets = project.fileSnippets || [];
  const techStack = (analysis.techStack || []).join(', ');

  // 1. Try Gemini if configured
  if (process.env.GEMINI_API_KEY) {
    try {
      const { GoogleGenerativeAI } = await import('@google/generative-ai');
      const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
      const model = genAI.getGenerativeModel({ model: process.env.GEMINI_MODEL || 'gemini-3.1-flash-lite' });

      const repoContext = `You are GitInsight AI, an expert software engineering assistant answering questions about this repository.
Project: ${project.name}
Description: ${project.description || analysis.summary}
Tech Stack: ${techStack}
Files in repository (${fileTree.length} files):
${fileTree.slice(0, 50).join('\n')}

Key File Snippets:
${fileSnippets.slice(0, 5).map((s) => `--- File: ${s.name} ---\n${s.content?.slice(0, 600)}`).join('\n\n')}

User Question: ${message}

Provide a helpful, precise, technical answer. Reference specific files, endpoints, or architectural components wherever applicable.`;

      const res = await model.generateContent(repoContext);
      const text = res.response.text();
      if (text) return text;
    } catch (err) {
      console.warn('[GitInsight AI Chat] Gemini chat unavailable, using repository retrieval:', err.message);
    }
  }

  // 2. Intelligent Grounded Retrieval Fallback
  let matchedFiles = [];

  if (query.includes('auth') || query.includes('login') || query.includes('jwt') || query.includes('password') || query.includes('token')) {
    matchedFiles = fileTree.filter((f) => /auth|login|jwt|token|user|middleware/i.test(f));
    return `### 🔐 Authentication Architecture in **${project.name}**\n\n` +
      `Authentication is managed primarily through the following components:\n\n` +
      (matchedFiles.length
        ? matchedFiles.map((f) => `- **\`${f}\`**: Implements authentication routes, token generation, or protected request middleware.`).join('\n')
        : `- **Auth Middleware & Controllers**: Inspects incoming HTTP \`Authorization: Bearer <token>\` headers.`) +
      `\n\n**Key Flow:**\n` +
      `1. **Login Request:** The client sends credentials to the auth route (e.g. \`/api/auth/login\`).\n` +
      `2. **Verification & Signing:** Passwords are verified (e.g. via \`bcrypt\`) and a signed JWT is returned.\n` +
      `3. **Protected Guard:** Routes protect resources by validating tokens before passing execution to controllers.\n\n` +
      `*Recommendation: Always verify \`JWT_SECRET\` is sourced from environment variables with strong entropy.*`;
  }

  if (query.includes('api') || query.includes('route') || query.includes('endpoint')) {
    matchedFiles = fileTree.filter((f) => /route|controller|api|server/i.test(f));
    const apis = analysis.architecture?.components?.apis || [];
    return `### 🌐 API Architecture & Routes in **${project.name}**\n\n` +
      `This project structures its REST endpoints through decoupled routing and controller layers:\n\n` +
      `**Detected Endpoints:**\n` +
      (apis.length ? apis.map((a) => `- \`${a}\``).join('\n') : `- Standard REST CRUD routes`) +
      `\n\n**Relevant Files:**\n` +
      matchedFiles.slice(0, 6).map((f) => `- **\`${f}\`**`).join('\n') +
      `\n\n*All endpoints return structured JSON with standard HTTP status codes.*`;
  }

  if (query.includes('security') || query.includes('vulnerability') || query.includes('risk') || query.includes('secret')) {
    const vulns = analysis.securityAudit?.vulnerabilities || [];
    return `### 🛡️ Security Audit Findings for **${project.name}**\n\n` +
      `**Overall Security Score:** ${analysis.scores?.security || 80}/100\n\n` +
      `**Key Observations:**\n` +
      (vulns.length
        ? vulns.slice(0, 4).map((v) => `- **[${v.severity.toUpperCase()}]** ${v.title} in \`${v.file}\`: ${v.remediation}`).join('\n')
        : `- No critical static vulnerabilities flagged.`) +
      `\n\n*Ensure \`.env\` is listed in \`.gitignore\` and rotate sensitive API tokens frequently.*`;
  }

  if (query.includes('test') || query.includes('testing') || query.includes('coverage') || query.includes('jest')) {
    const tests = analysis.testSuite?.generatedTests || [];
    return `### 🧪 Test Suite & Quality Status for **${project.name}**\n\n` +
      `**Estimated Coverage:** ${analysis.testSuite?.testCoverageEstimate || 30}%\n\n` +
      `**Generated Test Scenarios Available:**\n` +
      tests.slice(0, 3).map((t) => `- **${t.testName}** (\`${t.targetFile}\` - ${t.category})`).join('\n') +
      `\n\n*You can view and simulate running the complete test suite in the **Test Suite** tab!*`;
  }

  if (query.includes('modify') || query.includes('add a feature') || query.includes('where to start')) {
    return `### 🛠️ Developer Guide: Adding Features to **${project.name}**\n\n` +
      `To extend this codebase systematically, follow these steps:\n\n` +
      `1. **Data Model:** If adding a new entity, create a new schema in the \`models/\` directory.\n` +
      `2. **Business Logic:** Create or update the corresponding handler in \`controllers/\` or \`services/\`.\n` +
      `3. **API Route:** Expose the endpoint under \`routes/\` and link it to the central router.\n` +
      `4. **Frontend Integration:** Add the fetch call in the frontend API client and bind it to UI components.\n` +
      `5. **Automated Test:** Write unit tests for both valid data and edge-case boundaries.`;
  }

  // Generic grounded summary answer
  return `### 💡 Repository Insights for **${project.name}**\n\n` +
    `**Tech Stack:** ${techStack}\n` +
    `**Analyzed Files:** ${fileTree.length} total files\n\n` +
    `**Summary:** ${analysis.summary}\n\n` +
    `You can ask specific questions about:\n` +
    `- *"Where is authentication implemented?"*\n` +
    `- *"How does the API request lifecycle work?"*\n` +
    `- *"What security vulnerabilities were detected?"*\n` +
    `- *"Which files should I edit to add a new feature?"*`;
}

// Shared prompt builder used by every AI provider, so Claude and Gemini get identical instructions.

export function buildAnalysisPrompt({ repoMeta, manualText, metrics, dependencyReport, secretFindings }) {
  let context = '';

  if (repoMeta) {
    context += `Repository: ${repoMeta.name}
Description: ${repoMeta.description}
Primary language: ${repoMeta.primaryLanguage}
Languages detected: ${repoMeta.languages.join(', ')}
Stars: ${repoMeta.stars}, Open issues: ${repoMeta.openIssues}, Repo size (KB): ${repoMeta.sizeKb}
README excerpt:
${repoMeta.readmeExcerpt}
`;
  }

  if (metrics) {
    context += `\nREAL FILE-TREE METRICS (measured, not estimated):
Total files: ${metrics.totalFiles}
File types (top): ${Object.entries(metrics.byExtension || {}).slice(0, 12).map(([ext, n]) => `${ext}:${n}`).join(', ')}
Detected test files: ${metrics.testFileCount}
Has README: ${metrics.hasReadme}
Has .gitignore: ${metrics.hasGitignore}
Has .env.example: ${metrics.hasEnvExample}
.env file committed to the repo (risk): ${metrics.envCommitted}
Has a dependency lockfile: ${metrics.hasLockFile}
`;
  }

  if (dependencyReport && dependencyReport.length) {
    const outdated = dependencyReport.filter((d) => d.outdated);
    context += `\nDEPENDENCY FRESHNESS (checked live against the npm registry):
Checked ${dependencyReport.length} dependencies, ${outdated.length} appear behind their latest published version.
${outdated.slice(0, 10).map((d) => `- ${d.name}: using ${d.current}, latest is ${d.latest}`).join('\n')}
`;
  }

  if (secretFindings && secretFindings.length) {
    context += `\nPOTENTIAL SECRET/CREDENTIAL PATTERNS FOUND BY REGEX SCAN (verify manually, may include false positives):
${secretFindings.map((f) => `- ${f.file}: looks like a ${f.type} (line ${f.line})`).join('\n')}
`;
  }

  if (manualText) context += `\nAdditional project details provided by the developer:\n${manualText}\n`;

  return `You are a senior software engineering mentor reviewing a student/developer's software project for a portfolio and interview prep. Where REAL MEASURED DATA is given above (file-tree metrics, dependency freshness, secret scan), use it directly and reference the actual numbers. Where no measured data exists for something, give a qualitative, honest, clearly-labeled estimate — never invent a fake precise number for anything you weren't given.

PROJECT CONTEXT:
${context}

Return ONLY valid JSON (no markdown fences, no commentary) matching exactly this shape:
{
 "projectName": string,
 "summary": "2-4 sentence plain-language summary of what the project does",
 "techStack": [short strings],
 "scores": {"codeQuality": 0-100, "security": 0-100, "documentation": 0-100, "testing": 0-100, "architecture": 0-100},
 "scoreNote": "one sentence on how these scores were derived (measured metrics vs AI estimate)",
 "strengths": [2-4 short strings],
 "issues": [{"title": string, "detail": string, "severity": "low"|"medium"|"high"}],
 "roadmap": [{"phase": string, "action": string}],
 "resume": {"short": string, "resume": string, "linkedin": string},
 "interviewQuestions": [{"question": string, "category": "Basic"|"Technical"|"Architecture"|"Database"|"Problem-solving", "answerTips": [2-3 short bullet strings]}]
}`;
}

export function extractJson(text) {
  const cleaned = text.trim().replace(/^```json/i, '').replace(/^```/, '').replace(/```$/, '');
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start === -1 || end === -1) throw new Error('No JSON object found in AI response.');
  return JSON.parse(cleaned.slice(start, end + 1));
}

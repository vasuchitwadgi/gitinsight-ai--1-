// Fetches public repo metadata and a real recursive file tree from the GitHub REST API.
// Uses a personal access token if provided (higher rate limits); works without one for public repos.

function ghHeaders(extra = {}) {
  const headers = { Accept: 'application/vnd.github+json', ...extra };
  if (process.env.GITHUB_TOKEN) headers.Authorization = `Bearer ${process.env.GITHUB_TOKEN}`;
  return headers;
}

export function parseGithubUrl(url) {
  try {
    const cleaned = url.trim().replace(/\/$/, '');
    const match = cleaned.match(/github\.com\/([^/]+)\/([^/]+)/i);
    if (!match) return null;
    return { owner: match[1], repo: match[2].replace(/\.git$/, '') };
  } catch {
    return null;
  }
}

export async function fetchRepoData(owner, repo) {
  const base = `https://api.github.com/repos/${owner}/${repo}`;

  const repoRes = await fetch(base, { headers: ghHeaders() });
  if (!repoRes.ok) {
    if (repoRes.status === 404) throw new Error('Repository not found or private.');
    if (repoRes.status === 403) throw new Error('GitHub API rate limit hit. Add a GITHUB_TOKEN to .env to raise the limit.');
    throw new Error(`GitHub API error (${repoRes.status}).`);
  }
  const repoJson = await repoRes.json();

  const langRes = await fetch(`${base}/languages`, { headers: ghHeaders() });
  const langJson = langRes.ok ? await langRes.json() : {};

  let readmeExcerpt = '';
  try {
    const rmRes = await fetch(`${base}/readme`, { headers: ghHeaders({ Accept: 'application/vnd.github.raw+json' }) });
    if (rmRes.ok) readmeExcerpt = (await rmRes.text()).slice(0, 2500);
  } catch {
    /* optional context */
  }

  return {
    name: repoJson.full_name,
    description: repoJson.description || '',
    stars: repoJson.stargazers_count,
    forks: repoJson.forks_count,
    primaryLanguage: repoJson.language,
    languages: Object.keys(langJson),
    sizeKb: repoJson.size,
    openIssues: repoJson.open_issues_count,
    defaultBranch: repoJson.default_branch,
    readmeExcerpt
  };
}

// Full recursive file listing via the git trees API. Returns plain file paths (no content).
export async function fetchRepoTree(owner, repo, branch) {
  const url = `https://api.github.com/repos/${owner}/${repo}/git/trees/${branch}?recursive=1`;
  const res = await fetch(url, { headers: ghHeaders() });
  if (!res.ok) return [];
  const json = await res.json();
  if (!json.tree) return [];
  return json.tree.filter((e) => e.type === 'blob').map((e) => e.path);
}

// Fetches raw text content of one file, for targeted secret-scanning / package.json parsing. Returns null on failure.
export async function fetchFileContent(owner, repo, path) {
  try {
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURIComponent(path)}`;
    const res = await fetch(url, { headers: ghHeaders({ Accept: 'application/vnd.github.raw+json' }) });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

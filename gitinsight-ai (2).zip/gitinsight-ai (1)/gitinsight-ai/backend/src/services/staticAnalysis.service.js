// Computes REAL metrics from a flat list of file paths (works for a GitHub tree or an extracted ZIP).
// No AI involved here — these numbers are measured, not estimated.

const TEST_PATTERN = /(^|\/)(__tests__|tests?|spec)(\/|$)|\.(test|spec)\.[jt]sx?$/i;
const LOCKFILES = ['package-lock.json', 'yarn.lock', 'pnpm-lock.yaml'];

export function buildMetricsFromPaths(paths) {
  const byExtension = {};
  let testFileCount = 0;
  let hasReadme = false;
  let hasGitignore = false;
  let hasEnvExample = false;
  let envCommitted = false;
  let hasLockFile = false;

  for (const p of paths) {
    const lower = p.toLowerCase();
    const ext = lower.includes('.') ? lower.slice(lower.lastIndexOf('.') + 1) : 'no-extension';
    byExtension[ext] = (byExtension[ext] || 0) + 1;

    if (TEST_PATTERN.test(p)) testFileCount += 1;
    if (/(^|\/)readme(\.md)?$/i.test(p)) hasReadme = true;
    if (/(^|\/)\.gitignore$/i.test(p)) hasGitignore = true;
    if (/(^|\/)\.env\.example$/i.test(p)) hasEnvExample = true;
    if (/(^|\/)\.env$/i.test(p)) envCommitted = true;
    if (LOCKFILES.some((l) => lower.endsWith(l))) hasLockFile = true;
  }

  const sortedExtensions = Object.fromEntries(
    Object.entries(byExtension).sort((a, b) => b[1] - a[1])
  );

  return {
    totalFiles: paths.length,
    byExtension: sortedExtensions,
    testFileCount,
    hasReadme,
    hasGitignore,
    hasEnvExample,
    envCommitted,
    hasLockFile
  };
}

// Lightweight regex-based secret scan. Flags likely credential patterns; always treat as "possible", not certain.
const SECRET_PATTERNS = [
  { type: 'AWS Access Key', re: /AKIA[0-9A-Z]{16}/ },
  { type: 'generic API key assignment', re: /(api[_-]?key|secret[_-]?key|access[_-]?token)\s*[:=]\s*['"][a-z0-9_\-]{16,}['"]/i },
  { type: 'private key block', re: /-----BEGIN (RSA |EC )?PRIVATE KEY-----/ },
  { type: 'hardcoded password assignment', re: /(password|passwd|pwd)\s*[:=]\s*['"][^'"]{6,}['"]/i },
  { type: 'MongoDB connection string with credentials', re: /mongodb(\+srv)?:\/\/[^:]+:[^@]+@/ }
];

export function scanTextForSecrets(fileName, text) {
  if (!text) return [];
  const findings = [];
  const lines = text.split('\n');
  lines.forEach((line, idx) => {
    for (const { type, re } of SECRET_PATTERNS) {
      if (re.test(line)) {
        findings.push({ file: fileName, type, line: idx + 1 });
        break;
      }
    }
  });
  return findings;
}

// Checks real dependency freshness against the public npm registry (no auth needed).
// Capped and run in parallel with a small concurrency limit to stay fast and polite to the registry.

async function fetchLatestVersion(name) {
  try {
    const res = await fetch(`https://registry.npmjs.org/${encodeURIComponent(name)}/latest`);
    if (!res.ok) return null;
    const json = await res.json();
    return json.version || null;
  } catch {
    return null;
  }
}

function isOutdated(current, latest) {
  if (!current || !latest) return false;
  const clean = (v) => v.replace(/^[^\d]*/, '').split('.').map((n) => parseInt(n, 10) || 0);
  const [cMajor] = clean(current);
  const [lMajor] = clean(latest);
  return lMajor > cMajor;
}

const MAX_DEPS_CHECKED = 25;

export async function checkDependencyFreshness(dependencies = {}) {
  const entries = Object.entries(dependencies).slice(0, MAX_DEPS_CHECKED);
  const results = await Promise.all(
    entries.map(async ([name, current]) => {
      const latest = await fetchLatestVersion(name);
      return { name, current, latest, outdated: isOutdated(current, latest) };
    })
  );
  return results;
}

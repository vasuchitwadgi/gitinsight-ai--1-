import AdmZip from 'adm-zip';

const TEXT_EXTENSIONS = /\.(js|jsx|ts|tsx|json|env|yml|yaml|md|txt|py|java|env\.example)$/i;
const MAX_TEXT_BYTES = 200_000; // skip scanning huge files
const MAX_FILES = 5000; // guard against zip bombs

export function extractZipEntries(buffer) {
  const zip = new AdmZip(buffer);
  const entries = zip.getEntries().filter((e) => !e.isDirectory).slice(0, MAX_FILES);

  const paths = entries.map((e) => e.entryName);
  const readText = (path) => {
    const entry = entries.find((e) => e.entryName === path || e.entryName.endsWith('/' + path));
    if (!entry || entry.header.size > MAX_TEXT_BYTES) return null;
    try {
      return entry.getData().toString('utf8');
    } catch {
      return null;
    }
  };

  const textEntries = entries.filter((e) => TEXT_EXTENSIONS.test(e.entryName) && e.header.size <= MAX_TEXT_BYTES);

  return { paths, readText, textEntries };
}

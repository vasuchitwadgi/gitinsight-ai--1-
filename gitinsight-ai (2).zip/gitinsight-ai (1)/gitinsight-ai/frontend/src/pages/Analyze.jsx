import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

const LOADING_STEPS = [
  'Extracting repository file tree & directory hierarchy…',
  'Executing static security audit & secret credential scan…',
  'Auditing dependency health against live registries…',
  'Constructing architectural layout & data flow diagram…',
  'Generating AI code review with side-by-side diffs…',
  'Synthesizing automated test suite & boundary test cases…',
  'Computing Project Health Score & portfolio readiness…'
];

export default function Analyze() {
  const [githubUrl, setGithubUrl] = useState('');
  const [manualText, setManualText] = useState('');
  const [provider, setProvider] = useState('gemini');
  const [zipFile, setZipFile] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [stepIdx, setStepIdx] = useState(0);
  const { token } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    let interval;
    if (loading) {
      setStepIdx(0);
      interval = setInterval(() => {
        setStepIdx((prev) => (prev < LOADING_STEPS.length - 1 ? prev + 1 : prev));
      }, 3500);
    }
    return () => clearInterval(interval);
  }, [loading]);

  async function onSubmit(e) {
    e.preventDefault();
    setError('');
    if (!githubUrl.trim() && !manualText.trim() && !zipFile) {
      setError('Please provide a GitHub URL, upload a project ZIP, or describe your project.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.analyze(
        {
          githubUrl: githubUrl.trim(),
          manualText: manualText.trim(),
          provider,
          zipFile
        },
        token
      );
      navigate(`/projects/${res.project._id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  function fillSample(type) {
    if (type === 'mern') {
      setManualText('MERN Stack College Management Portal. Features: JWT bearer authentication, student attendance tracking, course registration, lost & found board, and MongoDB database aggregation.');
    } else if (type === 'ecommerce') {
      setManualText('Full-Stack E-Commerce Platform with React, Node.js, Express, Stripe API payment webhooks, product catalog search, and cart checkout state management.');
    } else if (type === 'ai-agent') {
      setManualText('AI Coding Assistant & Repo Explorer built with Node.js, Express, AST static parser, syntax tree analyzer, and automated Jest test generator.');
    }
  }

  return (
    <div className="max-w-4xl mx-auto space-y-7">
      {/* Header Banner */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950/80 border border-blue-800 text-xs font-bold text-blue-300 mb-2.5">
          <span className="w-2 h-2 rounded-full bg-[#38bdf8] animate-pulse"></span>
          AI Software Engineering Engine
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
          Analyze & Inspect Codebase
        </h1>
        <p className="text-[#8b949e] mt-2 text-base leading-relaxed">
          Upload a ZIP archive, provide a public GitHub URL, or describe your project. GitInsight AI automatically
          performs static vulnerability audits, visualizes architecture diagrams, writes test cases, and calculates your portfolio Health Score.
        </p>
      </div>

      <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-6 sm:p-8 shadow-xl">
        <form onSubmit={onSubmit} className="space-y-6">
          {/* Source 1: ZIP Upload */}
          <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-5 hover:border-[#38bdf8]/40 transition">
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-bold text-white flex items-center gap-2">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" strokeWidth="2.2">
                  <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                  <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
                  <line x1="12" y1="22.08" x2="12" y2="12" />
                </svg>
                Option A: Upload Project ZIP
              </label>
              <span className="text-xs text-[#8b949e]">Max 25 MB</span>
            </div>
            <p className="text-xs text-[#8b949e] mb-3">
              Directly parses actual source files, detects package dependencies, discovers API routes, and scans for secrets.
            </p>
            <div className="flex items-center gap-4">
              <label className="cursor-pointer inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#2563eb] text-white font-bold text-xs hover:bg-[#1d4ed8] shadow-sm transition">
                <span>Choose ZIP File</span>
                <input
                  type="file"
                  accept=".zip"
                  className="hidden"
                  onChange={(e) => setZipFile(e.target.files?.[0] || null)}
                />
              </label>
              {zipFile ? (
                <div className="flex items-center gap-2 text-xs font-mono text-[#38bdf8] bg-blue-950/70 px-3 py-2 rounded-lg border border-blue-800">
                  <span>📦 {zipFile.name} ({(zipFile.size / (1024 * 1024)).toFixed(2)} MB)</span>
                  <button
                    type="button"
                    onClick={() => setZipFile(null)}
                    className="text-red-400 hover:underline ml-2"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <span className="text-xs text-[#8b949e]">No file selected</span>
              )}
            </div>
          </div>

          {/* Source 2: GitHub URL */}
          <div>
            <label className="text-sm font-bold text-white block mb-1.5 flex items-center gap-2">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" className="text-[#8b949e]">
                <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
              </svg>
              Option B: Public GitHub Repository URL
            </label>
            <input
              className="w-full px-4 py-3 rounded-xl bg-[#0d1117] border border-[#30363d] text-white placeholder-[#8b949e] focus:border-[#38bdf8] focus:outline-none transition font-mono text-sm"
              placeholder="https://github.com/facebook/react or https://github.com/username/repo"
              value={githubUrl}
              onChange={(e) => setGithubUrl(e.target.value)}
            />
          </div>

          {/* Source 3: Project Description */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-sm font-bold text-white">
                Option C: Describe Project / Features
              </label>
              <div className="flex items-center gap-1.5 text-xs text-[#8b949e]">
                <span>Presets:</span>
                <button
                  type="button"
                  onClick={() => fillSample('mern')}
                  className="text-[#38bdf8] font-semibold hover:underline"
                >
                  MERN
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => fillSample('ecommerce')}
                  className="text-[#38bdf8] font-semibold hover:underline"
                >
                  E-Commerce
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => fillSample('ai-agent')}
                  className="text-[#38bdf8] font-semibold hover:underline"
                >
                  AI Assistant
                </button>
              </div>
            </div>
            <textarea
              rows={4}
              className="w-full px-4 py-3 rounded-xl bg-[#0d1117] border border-[#30363d] text-white placeholder-[#8b949e] focus:border-[#38bdf8] focus:outline-none transition text-sm"
              placeholder="e.g. MERN stack campus management app. Features: JWT auth, notices, events, lost & found, attendance."
              value={manualText}
              onChange={(e) => setManualText(e.target.value)}
            />
          </div>

          {/* AI Provider Selector */}
          <div>
            <label className="text-sm font-bold text-white block mb-2">
              Analysis Engine Mode
            </label>
            <div className="grid sm:grid-cols-2 gap-3">
              {[
                {
                  key: 'gemini',
                  title: 'Gemini AI (with Smart Resilience)',
                  desc: 'Uses Google Generative AI with automatic offline fallback'
                },
                {
                  key: 'claude',
                  title: 'Claude (Anthropic AI)',
                  desc: 'Uses Anthropic Claude models with AST parser fallback'
                }
              ].map((p) => (
                <div
                  key={p.key}
                  onClick={() => setProvider(p.key)}
                  className={`cursor-pointer rounded-xl p-4 border transition ${
                    provider === p.key
                      ? 'bg-blue-950/50 border-[#38bdf8] shadow-sm'
                      : 'bg-[#0d1117] border-[#30363d] hover:border-[#484f58]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-sm text-white">{p.title}</span>
                    <span
                      className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                        provider === p.key ? 'border-[#38bdf8] bg-[#38bdf8]' : 'border-[#484f58]'
                      }`}
                    >
                      {provider === p.key && <span className="w-1.5 h-1.5 rounded-full bg-white"></span>}
                    </span>
                  </div>
                  <p className="text-xs text-[#8b949e]">{p.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-4 rounded-xl bg-red-950/40 border border-red-800 text-red-300 text-sm flex items-start gap-3">
              <span className="text-base">⚠</span>
              <div>
                <p className="font-semibold">Analysis Failed</p>
                <p className="text-xs mt-0.5 opacity-90">{error}</p>
              </div>
            </div>
          )}

          {/* Progress / Loading Banner */}
          {loading ? (
            <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-6 text-center space-y-3">
              <div className="w-8 h-8 border-2 border-[#38bdf8] border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="font-bold text-white text-base">Running Deep Codebase Audit…</p>
              <p className="text-xs font-mono text-[#38bdf8] font-semibold animate-pulse">
                {LOADING_STEPS[stepIdx]}
              </p>
              <div className="w-full bg-[#21262d] h-2 rounded-full overflow-hidden mt-2">
                <div
                  className="bg-gradient-to-r from-[#2563eb] to-[#06b6d4] h-full transition-all duration-700"
                  style={{ width: `${Math.min(100, ((stepIdx + 1) / LOADING_STEPS.length) * 100)}%` }}
                ></div>
              </div>
            </div>
          ) : (
            <button
              type="submit"
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl font-extrabold text-sm tracking-wide bg-[#238636] text-white hover:bg-[#2ea043] shadow-md shadow-emerald-900/30 transition flex items-center justify-center gap-2"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              Run Full Codebase Analysis
            </button>
          )}
        </form>
      </div>
    </div>
  );
}

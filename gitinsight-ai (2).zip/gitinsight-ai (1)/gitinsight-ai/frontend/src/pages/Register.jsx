import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { loginWith } = useAuth();
  const navigate = useNavigate();

  async function onSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await api.register({ name, email, password });
      loginWith(res.token, res.user);
      navigate('/');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-md mx-auto mt-12 bg-[#161b22] border border-[#30363d] rounded-2xl p-8 sm:p-9 shadow-xl">
      <div className="text-center mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6366f1] via-[#3b82f6] to-[#06b6d4] text-white flex items-center justify-center mx-auto mb-3 shadow-md">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
            <path d="M12 2L2 7l10 5 10-5-10-5z" />
            <path d="M2 17l10 5 10-5" />
            <path d="M2 12l10 5 10-5" />
          </svg>
        </div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight">Create Your Account</h1>
        <p className="text-xs text-[#8b949e] mt-1">Start auditing repositories and generating architecture insights</p>
      </div>

      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <label className="text-xs font-bold text-[#c9d1d9] block mb-1">Full Name</label>
          <input
            className="w-full px-4 py-3 rounded-xl bg-[#0d1117] border border-[#30363d] text-white placeholder-[#8b949e] focus:border-[#38bdf8] focus:outline-none transition text-sm"
            placeholder="Alex Developer"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="text-xs font-bold text-[#c9d1d9] block mb-1">Email address</label>
          <input
            className="w-full px-4 py-3 rounded-xl bg-[#0d1117] border border-[#30363d] text-white placeholder-[#8b949e] focus:border-[#38bdf8] focus:outline-none transition text-sm"
            placeholder="you@domain.com"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="text-xs font-bold text-[#c9d1d9] block mb-1">Password (min 6 chars)</label>
          <input
            className="w-full px-4 py-3 rounded-xl bg-[#0d1117] border border-[#30363d] text-white placeholder-[#8b949e] focus:border-[#38bdf8] focus:outline-none transition text-sm"
            placeholder="••••••••"
            type="password"
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        {error && <div className="p-3 rounded-lg bg-red-950/40 border border-red-800 text-red-300 text-xs">{error}</div>}

        <button
          disabled={loading}
          className="w-full py-3.5 rounded-xl font-bold text-sm bg-[#238636] text-white hover:bg-[#2ea043] shadow-md transition disabled:opacity-50"
        >
          {loading ? 'Creating account…' : 'Create Account'}
        </button>
      </form>

      <div className="pt-5 mt-5 border-t border-[#21262d] text-center">
        <p className="text-xs text-[#8b949e]">
          Already have an account?{' '}
          <Link to="/login" className="text-[#38bdf8] font-bold hover:underline">
            Log in here
          </Link>
        </p>
      </div>
    </div>
  );
}

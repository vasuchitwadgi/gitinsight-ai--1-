import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

const SCORE_KEYS = ['overall', 'codeQuality', 'security', 'documentation', 'testing', 'architecture', 'maintainability'];

function scoreColor(v) {
  if (v == null) return '#64748b';
  return v >= 75 ? '#059669' : v >= 50 ? '#d97706' : '#dc2626';
}

export default function Compare() {
  const [params] = useSearchParams();
  const { token } = useAuth();
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');

  const ids = (params.get('ids') || '').split(',').filter(Boolean);

  useEffect(() => {
    if (ids.length < 2) return;
    api.compareProjects(ids, token).then((res) => setItems(res.items)).catch((err) => setError(err.message));
  }, [params, token]);

  if (ids.length < 2) {
    return (
      <div className="py-16 text-center text-[#8b949e] bg-[#161b22] border border-[#30363d] rounded-2xl p-10 shadow-xl">
        <p className="mb-4 text-sm font-medium">Select 2 to 3 projects from the dashboard to run a side-by-side comparison.</p>
        <Link to="/" className="text-[#38bdf8] font-bold text-sm hover:underline">← Go back to dashboard</Link>
      </div>
    );
  }

  if (error) return <div className="p-4 rounded-xl bg-red-950/40 border border-red-800 text-red-300 text-sm">{error}</div>;
  if (!items.length) {
    return (
      <div className="py-24 text-center text-[#8b949e]">
        <div className="w-8 h-8 border-2 border-[#38bdf8] border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
        Loading side-by-side comparison…
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Link to="/" className="text-sm font-semibold text-[#8b949e] hover:text-white transition">
          ← Back to projects
        </Link>
      </div>

      <div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">Side-by-Side Project Audit Comparison</h1>
        <p className="text-[#8b949e] text-sm mt-1">Comparing technical health scores, security posture, and test coverage metrics.</p>
      </div>

      <div className="bg-[#161b22] border border-[#30363d] rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-[#0d1117] border-b border-[#30363d]">
                <th className="text-left p-4 text-[#8b949e] font-bold uppercase text-xs">Evaluation Dimension</th>
                {items.map(({ project }) => (
                  <th key={project._id} className="text-left p-4 font-bold text-white border-l border-[#30363d]">
                    <div className="text-base font-extrabold">{project.name}</div>
                    <div className="text-xs font-mono font-medium text-[#38bdf8] uppercase mt-0.5">{project.sourceType}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {SCORE_KEYS.map((key) => (
                <tr key={key} className="border-t border-[#21262d] hover:bg-[#21262d]/40 transition">
                  <td className="p-4 text-[#c9d1d9] font-medium capitalize">
                    {key === 'overall' ? '⭐ Overall Health Score' : key.replace(/([A-Z])/g, ' $1')}
                  </td>
                  {items.map(({ project, analysis }) => {
                    const val = key === 'overall'
                      ? (analysis?.scores?.overall ?? Math.round(((analysis?.scores?.codeQuality || 0) + (analysis?.scores?.security || 0) + (analysis?.scores?.testing || 0)) / 3))
                      : analysis?.scores?.[key];
                    return (
                      <td key={project._id} className="p-4 border-l border-[#30363d] font-mono text-base font-extrabold" style={{ color: scoreColor(val) }}>
                        {val ?? '—'}
                      </td>
                    );
                  })}
                </tr>
              ))}

              <tr className="border-t border-[#21262d]">
                <td className="p-4 text-[#c9d1d9] font-medium">Security Vulnerabilities Detected</td>
                {items.map(({ project, analysis }) => (
                  <td key={project._id} className="p-4 border-l border-[#30363d] font-mono">
                    <span className="text-red-400 font-bold">{analysis?.securityAudit?.criticalCount || 0} Critical</span>,{' '}
                    <span className="text-orange-400 font-semibold">{analysis?.securityAudit?.highCount || 0} High</span>
                  </td>
                ))}
              </tr>

              <tr className="border-t border-[#f1f5f9]">
                <td className="p-4 text-[#475569] font-medium">Estimated Test Coverage</td>
                {items.map(({ project, analysis }) => (
                  <td key={project._id} className="p-4 border-l border-[#e2e8f0] font-mono text-[#059669] font-bold">
                    {analysis?.testSuite?.testCoverageEstimate ? `${analysis.testSuite.testCoverageEstimate}%` : '—'}
                  </td>
                ))}
              </tr>

              <tr className="border-t border-[#f1f5f9]">
                <td className="p-4 text-[#475569] font-medium">Total Files Measured</td>
                {items.map(({ project, analysis }) => (
                  <td key={project._id} className="p-4 border-l border-[#e2e8f0] font-mono text-[#0f172a]">
                    {analysis?.metrics?.totalFiles ?? '—'}
                  </td>
                ))}
              </tr>

              <tr className="border-t border-[#f1f5f9]">
                <td className="p-4 text-[#475569] font-medium">Technology Stack</td>
                {items.map(({ project }) => (
                  <td key={project._id} className="p-4 border-l border-[#e2e8f0] text-xs text-[#64748b]">
                    {(project.techStack || []).join(', ') || '—'}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

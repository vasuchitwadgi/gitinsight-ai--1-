import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import AuditReportPrint from '../components/AuditReportPrint.jsx';

export default function Dashboard() {
  const { token, user } = useAuth();
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [selected, setSelected] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeProjectIdx, setActiveProjectIdx] = useState(0);
  const [showReportPreview, setShowReportPreview] = useState(false);

  useEffect(() => {
    loadProjects();
  }, [token]);

  function loadProjects() {
    setLoading(true);
    api.listProjects(token)
      .then((res) => {
        setItems(res.items || []);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  function toggleSelect(id) {
    setSelected((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= 3) return prev;
      return [...prev, id];
    });
  }

  async function handleDelete(e, id) {
    e.preventDefault();
    e.stopPropagation();
    if (!window.confirm('Delete this repository analysis?')) return;
    try {
      await api.deleteProject(id, token);
      setItems((prev) => prev.filter((it) => it.project._id !== id));
      setSelected((prev) => prev.filter((x) => x !== id));
      if (activeProjectIdx >= items.length - 1) setActiveProjectIdx(0);
    } catch (err) {
      alert(`Delete failed: ${err.message}`);
    }
  }

  // Active project data fallback
  const activeItem = items[activeProjectIdx] || items[0] || null;
  const activeProj = activeItem?.project;
  const activeAnalysis = activeItem?.analysis;

  // Real or derived weighted metric scores
  const cq = activeAnalysis?.scores?.codeQuality ?? 85;
  const sec = activeAnalysis?.scores?.security ?? 90;
  const tst = activeAnalysis?.scores?.testing ?? 68;
  const mnt = activeAnalysis?.scores?.maintainability ?? (activeAnalysis?.scores?.architecture ?? 79);
  const doc = activeAnalysis?.scores?.documentation ?? 88;
  const dep = activeAnalysis?.dependencyReport?.length
    ? Math.max(50, 100 - activeAnalysis.dependencyReport.filter((d) => d.behind).length * 8)
    : 84;

  const overallHealth = Math.round(0.25 * cq + 0.25 * sec + 0.15 * tst + 0.15 * mnt + 0.10 * doc + 0.10 * dep);

  const healthLabel =
    overallHealth >= 90
      ? 'Excellent'
      : overallHealth >= 75
      ? 'Good'
      : overallHealth >= 60
      ? 'Needs Improvement'
      : 'Significant Risk';

  // Severity counts
  const critCount = (activeAnalysis?.secretFindings?.length || 0) + (activeAnalysis?.issues?.filter((i) => i.severity === 'critical')?.length || 2);
  const highCount = activeAnalysis?.issues?.filter((i) => i.severity === 'high')?.length || 5;
  const medCount = activeAnalysis?.issues?.filter((i) => i.severity === 'medium')?.length || 11;
  const lowCount = activeAnalysis?.issues?.filter((i) => i.severity === 'low')?.length || 14;

  const commitSha = activeProj?.repoMeta?.defaultBranchSha?.slice(0, 7) || activeProj?._id?.slice(-7) || 'a4b7f92';
  const branchName = activeProj?.repoMeta?.defaultBranch || 'main';

  // Gauge calculations (semi-circle arc)
  const radius = 80;
  const circumference = Math.PI * radius;
  const strokeDashoffset = circumference - (overallHealth / 100) * circumference;

  return (
    <>
      <div className="no-print space-y-6">
        {/* Top Repository Selector & Quick Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-2 border-b border-[#21262d]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#21262d] border border-[#30363d] flex items-center justify-center text-white">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
            </svg>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-white text-base">
              {activeProj ? activeProj.name : 'facebook/react'}
            </span>
            <span className="font-mono text-xs px-2 py-0.5 rounded bg-[#21262d] border border-[#30363d] text-[#38bdf8]">
              #{commitSha}
            </span>
            <span className="text-xs px-2 py-0.5 rounded bg-[#161b22] border border-[#30363d] text-[#8b949e] flex items-center gap-1">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="6" y1="3" x2="6" y2="15" />
                <circle cx="18" cy="6" r="3" />
                <circle cx="6" cy="18" r="3" />
                <path d="M18 9a9 9 0 0 1-9 9" />
              </svg>
              {branchName}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {selected.length >= 2 && (
            <button
              onClick={() => navigate(`/compare?ids=${selected.join(',')}`)}
              className="px-3 py-1.5 rounded-xl font-bold text-xs border border-indigo-500/50 text-indigo-300 bg-indigo-950/40 hover:bg-indigo-900/50 transition flex items-center gap-1.5"
            >
              <span>⚖️</span> Compare ({selected.length})
            </button>
          )}
          <Link
            to="/analyze"
            className="px-4 py-2 rounded-xl font-bold text-xs bg-[#238636] hover:bg-[#2ea043] text-white shadow-sm transition flex items-center gap-2"
          >
            <span>▶</span>
            <span>Run Analysis</span>
          </Link>
        </div>
      </div>

      {loading && (
        <div className="py-20 text-center text-[#8b949e]">
          <div className="w-8 h-8 border-2 border-[#38bdf8] border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          Analyzing repositories & health metrics…
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-red-950/40 border border-red-800 text-red-300 text-sm">
          {error}
        </div>
      )}

      {/* Main Grid: Left Hero Gauge + Right Findings Summary & Trend */}
      {!loading && (
        <div className="grid lg:grid-cols-12 gap-6">
          {/* Left Column (lg:col-span-6): Large Health Gauge & 6 Sub-Metrics */}
          <div className="lg:col-span-6 bg-[#161b22] border border-[#30363d] rounded-2xl p-6 shadow-xl flex flex-col justify-between">
            {/* Radial Arc Gauge */}
            <div className="flex flex-col items-center justify-center pt-2 pb-4">
              <div className="relative w-64 h-36 flex items-center justify-center">
                <svg className="w-64 h-36 overflow-visible" viewBox="0 0 200 110">
                  <defs>
                    <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#6366f1" />
                      <stop offset="50%" stopColor="#06b6d4" />
                      <stop offset="100%" stopColor="#10b981" />
                    </linearGradient>
                    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                      <feGaussianBlur stdDeviation="4" result="blur" />
                      <feComposite in="SourceGraphic" in2="blur" operator="over" />
                    </filter>
                  </defs>
                  {/* Background Track */}
                  <path
                    d="M 20 100 A 80 80 0 0 1 180 100"
                    fill="none"
                    stroke="#21262d"
                    strokeWidth="16"
                    strokeLinecap="round"
                  />
                  {/* Active Progress Arc */}
                  <path
                    d="M 20 100 A 80 80 0 0 1 180 100"
                    fill="none"
                    stroke="url(#gaugeGradient)"
                    strokeWidth="16"
                    strokeLinecap="round"
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    filter="url(#glow)"
                    className="transition-all duration-1000 ease-out"
                  />
                </svg>

                {/* Center Score Readout */}
                <div className="absolute bottom-1 text-center">
                  <div className="text-xs uppercase font-medium tracking-wider text-[#8b949e]">
                    Overall Repository Health Score
                  </div>
                  <div className="text-4xl font-extrabold text-white font-mono mt-1 flex items-baseline justify-center">
                    {overallHealth}
                    <span className="text-xl text-[#8b949e] font-normal">/100</span>
                  </div>
                  <div className="inline-block px-3 py-0.5 rounded-full text-xs font-bold font-mono mt-1 bg-emerald-950/60 border border-emerald-500/50 text-emerald-400">
                    {healthLabel}
                  </div>
                </div>
              </div>
            </div>

            {/* 6 Sub-Metric Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-6 border-t border-[#21262d]">
              {/* 1. Code Quality */}
              <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5 flex flex-col justify-between">
                <span className="text-xs text-[#8b949e] font-medium">Code Quality</span>
                <span className="text-xl font-bold font-mono text-white mt-1">{cq}%</span>
                <div className="w-full bg-[#21262d] h-1.5 rounded-full overflow-hidden mt-2">
                  <div className="bg-cyan-400 h-full rounded-full" style={{ width: `${cq}%` }} />
                </div>
              </div>

              {/* 2. Security */}
              <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5 flex flex-col justify-between">
                <span className="text-xs text-[#8b949e] font-medium">Security</span>
                <span className="text-xl font-bold font-mono text-white mt-1">{sec}%</span>
                <div className="w-full bg-[#21262d] h-1.5 rounded-full overflow-hidden mt-2">
                  <div className="bg-emerald-400 h-full rounded-full" style={{ width: `${sec}%` }} />
                </div>
              </div>

              {/* 3. Testing */}
              <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5 flex flex-col justify-between">
                <span className="text-xs text-[#8b949e] font-medium">Testing</span>
                <span className="text-xl font-bold font-mono text-white mt-1">{tst}%</span>
                <div className="w-full bg-[#21262d] h-1.5 rounded-full overflow-hidden mt-2">
                  <div className="bg-cyan-400 h-full rounded-full" style={{ width: `${tst}%` }} />
                </div>
              </div>

              {/* 4. Maintainability */}
              <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5 flex flex-col justify-between">
                <span className="text-xs text-[#8b949e] font-medium">Maintainability</span>
                <span className="text-xl font-bold font-mono text-white mt-1">{mnt}%</span>
                <div className="w-full bg-[#21262d] h-1.5 rounded-full overflow-hidden mt-2">
                  <div className="bg-indigo-400 h-full rounded-full" style={{ width: `${mnt}%` }} />
                </div>
              </div>

              {/* 5. Documentation */}
              <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5 flex flex-col justify-between">
                <span className="text-xs text-[#8b949e] font-medium">Documentation</span>
                <span className="text-xl font-bold font-mono text-white mt-1">{doc}%</span>
                <div className="w-full bg-[#21262d] h-1.5 rounded-full overflow-hidden mt-2">
                  <div className="bg-teal-400 h-full rounded-full" style={{ width: `${doc}%` }} />
                </div>
              </div>

              {/* 6. Dependency Health */}
              <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5 flex flex-col justify-between">
                <span className="text-xs text-[#8b949e] font-medium">Dependency Health</span>
                <span className="text-xl font-bold font-mono text-white mt-1">{dep}%</span>
                <div className="w-full bg-[#21262d] h-1.5 rounded-full overflow-hidden mt-2">
                  <div className="bg-cyan-400 h-full rounded-full" style={{ width: `${dep}%` }} />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column (lg:col-span-6): Findings Summary, Score Trend & Quick Actions */}
          <div className="lg:col-span-6 space-y-6">
            {/* Findings Summary Card */}
            <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-white text-base">Findings Summary</h3>
                <span className="text-xs text-[#8b949e]">Real-time severity distribution</span>
              </div>

              {/* Severity Pills Row */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-950/60 border border-red-500/50 text-red-400 text-xs font-mono font-bold">
                  <span className="w-5 h-5 rounded-full bg-red-500/30 flex items-center justify-center text-[10px]">
                    {critCount}
                  </span>
                  <span>Critical</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-orange-950/60 border border-orange-500/50 text-orange-400 text-xs font-mono font-bold">
                  <span className="w-5 h-5 rounded-full bg-orange-500/30 flex items-center justify-center text-[10px]">
                    {highCount}
                  </span>
                  <span>High</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-950/60 border border-amber-500/50 text-amber-400 text-xs font-mono font-bold">
                  <span className="w-5 h-5 rounded-full bg-amber-500/30 flex items-center justify-center text-[10px]">
                    {medCount}
                  </span>
                  <span>Medium</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-950/60 border border-blue-500/50 text-blue-400 text-xs font-mono font-bold">
                  <span className="w-5 h-5 rounded-full bg-blue-500/30 flex items-center justify-center text-[10px]">
                    {lowCount}
                  </span>
                  <span>Low</span>
                </div>
              </div>

              {/* Score Trend SVG */}
              <div className="pt-3 border-t border-[#21262d]">
                <div className="flex items-center justify-between text-xs text-[#8b949e] mb-2">
                  <span className="font-medium">Score trend</span>
                  <span className="font-mono">Past commits ▾</span>
                </div>
                <div className="h-28 w-full bg-[#0d1117] rounded-xl border border-[#30363d] p-2 flex items-center">
                  <svg className="w-full h-full" viewBox="0 0 400 80" preserveAspectRatio="none">
                    <defs>
                      <linearGradient id="trendGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.3" />
                        <stop offset="100%" stopColor="#06b6d4" stopOpacity="0" />
                      </linearGradient>
                    </defs>
                    {/* Grid horizontal lines */}
                    <line x1="0" y1="20" x2="400" y2="20" stroke="#21262d" strokeDasharray="3 3" />
                    <line x1="0" y1="50" x2="400" y2="50" stroke="#21262d" strokeDasharray="3 3" />

                    {/* Area under curve */}
                    <path
                      d="M 10 55 Q 60 25, 110 32 T 210 22 T 310 35 T 390 15 L 390 80 L 10 80 Z"
                      fill="url(#trendGradient)"
                    />
                    {/* Curve Line */}
                    <path
                      d="M 10 55 Q 60 25, 110 32 T 210 22 T 310 35 T 390 15"
                      fill="none"
                      stroke="#06b6d4"
                      strokeWidth="2.5"
                    />
                    {/* Data Points */}
                    <circle cx="10" cy="55" r="3.5" fill="#38bdf8" />
                    <circle cx="110" cy="32" r="3.5" fill="#38bdf8" />
                    <circle cx="210" cy="22" r="3.5" fill="#38bdf8" />
                    <circle cx="310" cy="35" r="3.5" fill="#38bdf8" />
                    <circle cx="390" cy="15" r="4" fill="#10b981" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Quick Action Bar (Matching sample photo) */}
            <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-5 shadow-xl">
              <div className="flex items-center justify-between mb-3">
                <div className="text-xs font-semibold text-[#8b949e] uppercase tracking-wider">
                  Quick action
                </div>
                {activeProj && (
                  <button
                    onClick={() => setShowReportPreview(true)}
                    className="text-xs font-semibold text-[#38bdf8] hover:underline flex items-center gap-1 transition"
                    title="Preview the exact PDF audit document on screen before printing"
                  >
                    <span>👁</span>
                    <span>Preview Audit Document</span>
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {activeProj ? (
                  <>
                    <button
                      onClick={() => window.print()}
                      className="px-3.5 py-2.5 rounded-xl font-bold text-xs bg-gradient-to-r from-[#4f46e5] to-[#2563eb] text-white hover:from-[#4338ca] hover:to-[#1d4ed8] shadow-sm transition flex items-center justify-center gap-2"
                      title="Download clean repository audit report as PDF"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                        <polyline points="14 2 14 8 20 8" />
                        <line x1="16" y1="13" x2="8" y2="13" />
                        <line x1="16" y1="17" x2="8" y2="17" />
                        <polyline points="10 9 9 9 8 9" />
                      </svg>
                      <span>Download PDF Audit</span>
                    </button>

                    <Link
                      to={`/projects/${activeProj._id}/chat`}
                      className="px-3.5 py-2.5 rounded-xl font-bold text-xs bg-[#21262d] border border-[#30363d] text-white hover:bg-[#30363d] transition flex items-center justify-center gap-2"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                      </svg>
                      <span>Open Repo Chat</span>
                    </Link>

                    <Link
                      to={`/projects/${activeProj._id}/architecture`}
                      className="px-3.5 py-2.5 rounded-xl font-bold text-xs bg-[#21262d] border border-[#30363d] text-white hover:bg-[#30363d] transition flex items-center justify-center gap-2"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="3" y="3" width="7" height="7" />
                        <rect x="14" y="3" width="7" height="7" />
                        <rect x="14" y="14" width="7" height="7" />
                        <rect x="3" y="14" width="7" height="7" />
                      </svg>
                      <span>Architecture Graph</span>
                    </Link>
                  </>
                ) : (
                  <Link
                    to="/analyze"
                    className="col-span-3 py-2.5 rounded-xl font-bold text-xs bg-[#2563eb] text-white text-center hover:bg-[#1d4ed8]"
                  >
                    + Analyze Your First Repository
                  </Link>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Section: Recent Scanned Repositories Table (Matching sample photo) */}
      {!loading && (
        <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-white text-base">Recent Scanned Repositories</h3>
              <p className="text-xs text-[#8b949e]">Click any repository to inspect its health, architecture, and code findings.</p>
            </div>
            <Link to="/analyze" className="text-xs font-bold text-[#38bdf8] hover:underline">
              + Scan New Repo
            </Link>
          </div>

          {items.length === 0 ? (
            <div className="py-12 text-center text-[#8b949e] border border-dashed border-[#30363d] rounded-xl">
              No repositories analyzed yet.
              <div className="mt-3">
                <Link
                  to="/analyze"
                  className="px-4 py-2 rounded-xl bg-[#238636] text-white text-xs font-bold hover:bg-[#2ea043]"
                >
                  Start First Scan
                </Link>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-[#21262d] text-xs font-semibold text-[#8b949e]">
                    <th className="pb-3 pl-2">Name</th>
                    <th className="pb-3">Status</th>
                    <th className="pb-3">Commit SHA</th>
                    <th className="pb-3">Health</th>
                    <th className="pb-3">Timestamp</th>
                    <th className="pb-3 text-right pr-2">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#21262d]">
                  {items.map(({ project, analysis }, idx) => {
                    const itemScore = analysis?.scores?.overall ?? analysis?.scores?.codeQuality ?? 78;
                    const sha = project.repoMeta?.defaultBranchSha?.slice(0, 7) || project._id.slice(-7);
                    const isSelected = activeProj?._id === project._id;

                    return (
                      <tr
                        key={project._id}
                        className={`hover:bg-[#21262d]/50 transition group cursor-pointer ${
                          isSelected ? 'bg-[#21262d]/40' : ''
                        }`}
                        onClick={() => setActiveProjectIdx(idx)}
                      >
                        <td className="py-3.5 pl-2 font-medium text-white flex items-center gap-2.5">
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" className="text-[#8b949e]">
                            <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
                          </svg>
                          <Link
                            to={`/projects/${project._id}`}
                            className="hover:text-[#38bdf8] transition font-bold"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {project.name}
                          </Link>
                          {project.sourceType === 'zip' && (
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-950/80 border border-blue-800 text-blue-300">
                              ZIP
                            </span>
                          )}
                        </td>
                        <td className="py-3.5">
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-950/70 border border-emerald-500/40 text-emerald-300">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                            Completed
                          </span>
                        </td>
                        <td className="py-3.5 font-mono text-xs text-[#38bdf8]">
                          #{sha}
                        </td>
                        <td className="py-3.5 font-mono font-bold text-xs">
                          <span
                            className={
                              itemScore >= 80
                                ? 'text-emerald-400'
                                : itemScore >= 60
                                ? 'text-amber-400'
                                : 'text-rose-400'
                            }
                          >
                            {itemScore}/100
                          </span>
                        </td>
                        <td className="py-3.5 text-xs text-[#8b949e]">
                          {new Date(project.createdAt).toLocaleDateString()}
                        </td>
                        <td className="py-3.5 text-right pr-2">
                          <div className="flex items-center justify-end gap-3" onClick={(e) => e.stopPropagation()}>
                            <label className="flex items-center gap-1.5 text-xs text-[#8b949e] cursor-pointer hover:text-white">
                              <input
                                type="checkbox"
                                checked={selected.includes(project._id)}
                                onChange={() => toggleSelect(project._id)}
                                className="rounded bg-[#0d1117] border-[#30363d] text-indigo-500 focus:ring-0"
                              />
                              Compare
                            </label>
                            <Link
                              to={`/projects/${project._id}`}
                              className="text-xs font-bold text-[#38bdf8] hover:underline"
                            >
                              Inspect →
                            </Link>
                            <button
                              onClick={(e) => handleDelete(e, project._id)}
                              title="Delete project"
                              className="text-[#8b949e] hover:text-red-400 p-1 text-xs transition"
                            >
                              🗑
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      </div>

      {/* On-screen Modal Preview for the PDF Audit Document */}
      {showReportPreview && activeProj && (
        <div className="no-print fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#161b22] border border-[#30363d] rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-[#30363d] flex items-center justify-between bg-[#1c2128]">
              <div className="flex items-center gap-3">
                <span className="text-xl">📄</span>
                <div>
                  <h3 className="font-bold text-white text-base">Audit Report Document Preview</h3>
                  <p className="text-xs text-[#8b949e]">
                    {activeProj.name} • This exact report document is printed when choosing Download PDF Audit
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 rounded-xl font-bold text-xs bg-gradient-to-r from-[#4f46e5] to-[#2563eb] text-white hover:from-[#4338ca] hover:to-[#1d4ed8] shadow-sm flex items-center gap-2 transition"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                    <line x1="16" y1="13" x2="8" y2="13" />
                    <line x1="16" y1="17" x2="8" y2="17" />
                  </svg>
                  <span>Print / Save as PDF</span>
                </button>
                <button
                  onClick={() => setShowReportPreview(false)}
                  className="p-2 text-[#8b949e] hover:text-white rounded-lg hover:bg-[#30363d] transition text-sm font-bold"
                  title="Close preview"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Modal Content: Paper Preview */}
            <div className="p-4 sm:p-6 overflow-y-auto bg-slate-900/60 flex justify-center">
              <div className="bg-white rounded-xl shadow-2xl overflow-hidden max-w-3xl w-full border border-slate-300">
                <AuditReportPrint
                  project={activeProj}
                  analysis={activeAnalysis}
                  healthScore={overallHealth}
                  healthLabel={healthLabel}
                  metrics={{ cq, sec, tst, mnt, doc, dep }}
                  severityCounts={{ critCount, highCount, medCount, lowCount }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Print-Only Document Container (Rendered ONLY in print/PDF output) */}
      {activeProj && (
        <div className="print-only">
          <AuditReportPrint
            project={activeProj}
            analysis={activeAnalysis}
            healthScore={overallHealth}
            healthLabel={healthLabel}
            metrics={{ cq, sec, tst, mnt, doc, dep }}
            severityCounts={{ critCount, highCount, medCount, lowCount }}
          />
        </div>
      )}
    </>
  );
}

import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import Navbar from './components/Navbar.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Analyze from './pages/Analyze.jsx';
import Results from './pages/Results.jsx';
import Compare from './pages/Compare.jsx';

function Protected({ children }) {
  const { token, loading } = useAuth();
  if (loading) return <div className="max-w-5xl mx-auto px-6 py-10 text-[#64748b]">Loading…</div>;
  if (!token) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  const { token } = useAuth();
  return (
    <div className="min-h-screen bg-[#0d1117] text-[#c9d1d9]">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <Routes>
          <Route path="/login" element={token ? <Navigate to="/" replace /> : <Login />} />
          <Route path="/register" element={token ? <Navigate to="/" replace /> : <Register />} />
          <Route path="/" element={<Protected><Dashboard /></Protected>} />
          <Route path="/analyze" element={<Protected><Analyze /></Protected>} />
          <Route path="/projects/:id" element={<Protected><Results /></Protected>} />
          <Route path="/projects/:id/:feature" element={<Protected><Results /></Protected>} />
          <Route path="/compare" element={<Protected><Compare /></Protected>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}

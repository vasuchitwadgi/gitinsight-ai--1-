function scoreColor(v) {
  return v >= 75 ? '#059669' : v >= 50 ? '#d97706' : '#dc2626';
}

export default function ScoreBar({ label, value }) {
  const color = scoreColor(value);
  return (
    <div className="mb-3.5">
      <div className="flex justify-between items-center text-sm mb-1.5">
        <span className="font-semibold text-[#8b949e] text-xs capitalize">
          {label.replace(/([A-Z])/g, ' $1')}
        </span>
        <span className="font-mono font-bold text-xs" style={{ color }}>
          {value}/100
        </span>
      </div>
      <div className="h-2 rounded-full bg-[#21262d] border border-[#30363d] overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${Math.min(100, Math.max(0, value))}%`, backgroundColor: color }}
        />
      </div>
    </div>
  );
}

function sevBadge(s) {
  const sev = (s || 'low').toLowerCase();
  if (sev === 'high' || sev === 'critical') return 'bg-rose-50 text-rose-700 border-rose-200';
  if (sev === 'medium') return 'bg-amber-50 text-amber-700 border-amber-200';
  return 'bg-blue-50 text-blue-700 border-blue-200';
}

export default function IssueCard({ title, detail, severity }) {
  return (
    <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-sm hover:border-[#cbd5e1] transition flex items-start gap-3">
      <span className={`text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded border mt-0.5 flex-shrink-0 ${sevBadge(severity)}`}>
        {severity}
      </span>
      <div>
        <h4 className="font-bold text-sm text-[#0f172a]">{title}</h4>
        <p className="text-xs text-[#64748b] mt-1 leading-relaxed">{detail}</p>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { api } from '../api/client.js';

export default function StudentProjectReport({
  project,
  analysis,
  token,
  onClose,
  initialEditMode = false
}) {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [regenerating, setRegenerating] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [showAiModal, setShowAiModal] = useState(false);
  const [activeTab, setActiveTab] = useState('meta');
  const [mode, setMode] = useState(initialEditMode ? 'edit' : 'preview'); // 'preview' | 'edit'
  const [error, setError] = useState('');

  const storageKey = `gitinsight_report_${project?._id}`;

  // Load report from API or localStorage or initialize default
  useEffect(() => {
    if (!project?._id) return;
    setLoading(true);

    api.getReport(project._id, token)
      .then((res) => {
        if (res.report) {
          // Check if local edits exist and are newer
          const cached = localStorage.getItem(storageKey);
          if (cached) {
            try {
              const parsed = JSON.parse(cached);
              setReport(parsed);
              return;
            } catch (e) {
              /* fallback to api report */
            }
          }
          setReport(res.report);
        }
      })
      .catch((err) => {
        // Fallback to local default synthesis
        console.warn('API getReport error, using local fallback:', err.message);
        const cached = localStorage.getItem(storageKey);
        if (cached) {
          try {
            setReport(JSON.parse(cached));
            return;
          } catch (e) {}
        }
        setReport(createLocalDefaultReport(project, analysis));
      })
      .finally(() => setLoading(false));
  }, [project?._id, token]);

  function createLocalDefaultReport(proj, ana) {
    const rawName = proj?.name || 'Software Project';
    const cleanTitle = rawName
      .split('/')
      .pop()
      .replace(/[-_]/g, ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase());

    const techStack = (ana?.techStack?.length ? ana.techStack : ['JavaScript', 'React', 'Node.js', 'Express', 'MongoDB']).join(', ');

    return {
      meta: {
        title: cleanTitle,
        degree: 'Bachelor of Technology in Computer Science & Engineering',
        studentName: 'Student Name',
        rollNo: 'USN: 1XX21CS001',
        guideName: 'Prof. Dr. Academic Supervisor, Ph.D',
        department: 'Department of Computer Science & Engineering',
        collegeName: 'Institute of Engineering and Technology',
        university: 'State Technological University',
        academicYear: '2024 - 2025',
        submissionMonthYear: 'May 2025'
      },
      frontMatter: {
        certificate: `This is to certify that the project report entitled "${cleanTitle}" submitted by Student Name (USN: 1XX21CS001) in partial fulfillment of the requirements for the award of the degree of Bachelor of Technology in Computer Science & Engineering is a bona fide record of the work carried out under my supervision.`,
        declaration: `I hereby declare that the project entitled "${cleanTitle}" submitted to the Department of Computer Science & Engineering is an authentic record of our original engineering work.`,
        acknowledgement: `We express our deep gratitude to our project guide for their mentorship, to the Head of Department, faculty, and our institution for providing the laboratories and technical environment to successfully execute this project.`,
        abstract: `Modern software systems demand high performance, modular architecture, and verifiable quality. The project "${cleanTitle}" addresses these challenges by developing a full-stack engineering solution utilizing ${techStack}. This report details the system architecture, requirements specifications, implementation algorithms, security defenses, and empirical test evaluations.`,
        keywords: ['Full-Stack Engineering', 'API Architecture', 'Static Analysis', 'Software Testing', 'Security Mitigation', 'Database Modeling']
      },
      chapter1_intro: {
        overview: `Software systems have become the foundational platform for contemporary organizational workflows. The project "${cleanTitle}" was conceived to establish a reliable, responsive, and secure software solution utilizing ${techStack}.`,
        problemStatement: `Conventional applications frequently face bottlenecks in maintainability, fragile state handling, and inadequate security boundary validation. This project solves these issues with modular service isolation, robust token authentication, and static code verification.`,
        objectives: [
          `Design and construct an end-to-end full-stack application for ${cleanTitle}.`,
          'Implement secure token-based authentication with encrypted credential storage.',
          'Enforce strict input validation, centralized error handling, and predictable API contracts.',
          'Synthesize automated unit and boundary test suites verifying system resilience.',
          'Conduct comprehensive static security audits and code quality benchmarking.'
        ],
        scope: `The system scope covers responsive client interfaces, RESTful API micro-services, and MongoDB document persistence. It is engineered for future horizontal scaling and containerized cloud deployment.`
      },
      chapter2_literature: {
        literatureSurvey: `Contemporary literature in computer science and software architecture emphasizes decoupled, component-based architectures. Following IEEE and Clean Architecture principles, separating business domain logic from transport protocols significantly reduces defect rates.`,
        existingSystemLimitations: [
          'Tightly coupled legacy architectures that impede unit testing.',
          'Vulnerability to unauthorized data access and unvalidated query parameters.',
          'Absence of automated static analysis and vulnerability alerting during development.',
          'Lack of responsive real-time feedback and intuitive visualization.'
        ],
        proposedSystem: `The proposed architecture for "${cleanTitle}" leverages an asynchronous non-blocking runtime with modular middleware pipelines. All transactions adhere to defensive programming standards and typed REST contracts.`,
        comparisonMatrix: [
          { feature: 'Architecture Pattern', existing: 'Script monolith', proposed: 'Modular Layered Micro-service' },
          { feature: 'Authentication Security', existing: 'Plain text / insecure cookies', proposed: 'Bcrypt Salted Hash + JWT Bearer Tokens' },
          { feature: 'Error Handling', existing: 'Unhandled runtime exceptions', proposed: 'Centralized Async Handler & Error Middleware' },
          { feature: 'Automated Testing', existing: 'Manual testing only', proposed: 'Automated Test Runner for Normal & Boundary Cases' }
        ]
      },
      chapter3_srs: {
        functionalRequirements: [
          { id: 'FR-01', name: 'User Authentication & Sessions', desc: 'Secure user registration, bcrypt password hashing, and signed JWT issuance.' },
          { id: 'FR-02', name: 'Codebase Ingestion & Parsing', desc: 'Accept ZIP archives or Git URLs, unpacking and parsing directory trees into syntax trees.' },
          { id: 'FR-03', name: 'Static Vulnerability Scanning', desc: 'Inspect source code for exposed secret credentials, code smells, and dependency risks.' },
          { id: 'FR-04', name: 'Interactive System Visualization', desc: 'Generate component topology and architecture graphs illustrating service flows.' },
          { id: 'FR-05', name: 'Automated Test Suite Runner', desc: 'Synthesize unit tests for boundary and edge conditions with pass/fail reporting.' },
          { id: 'FR-06', name: 'Project Report Generation', desc: 'Synthesize and export editable university-standard final year project reports.' }
        ],
        nonFunctionalRequirements: [
          { category: 'Performance', desc: 'API endpoints respond in <200ms; client page load under 1.5 seconds.' },
          { category: 'Security', desc: 'Zero plaintext passwords or secrets; HTTPS transport; rate-limited endpoints.' },
          { category: 'Reliability', desc: 'Automatic offline fallback engines ensure continuous availability without external API dependency.' }
        ],
        hardwareRequirements: {
          client: 'Standard PC/Laptop with minimum 4 GB RAM, 1080p display, and internet browser.',
          server: 'Dual/Quad-core CPU, 4-8 GB RAM, 20 GB SSD storage running Node.js and MongoDB.'
        },
        softwareRequirements: {
          operatingSystem: 'Windows 10/11, macOS, or Ubuntu Linux 20.04+',
          runtime: 'Node.js LTS (v18.0.0 or higher)',
          languages: 'JavaScript (ES6+), JSX, HTML5, CSS3',
          frontendFramework: 'React 18 with Vite and Tailwind CSS',
          backendFramework: 'Express.js RESTful API engine',
          database: 'MongoDB with Mongoose ODM schemas'
        }
      },
      chapter4_architecture: {
        overview: `The application follows a three-tier architecture: Presentation Tier (React single-page app), Logic Tier (Express RESTful API server), and Data Persistence Tier (MongoDB document database).`,
        modules: [
          { name: 'UI / Client Application', desc: 'Modular React components providing interactive dashboards, code review diffs, and report editing.' },
          { name: 'API Gateway & Security Middleware', desc: 'Handles JWT authorization, CORS negotiation, and JSON request validation.' },
          { name: 'Code Intelligence Engine', desc: 'AST static syntax tree parser and secret scanner analyzing code quality metrics.' },
          { name: 'Database Service', desc: 'Mongoose object relational mapping models persisting user accounts and project evaluations.' }
        ],
        dataFlow: `Client requests are authenticated via JWT bearer tokens at the API gateway. The request pipeline executes input validation, delegates to domain controller services, coordinates with MongoDB for persistence, and returns structured JSON responses.`
      },
      chapter5_implementation: {
        techStackRationale: `React was chosen for high-performance reactive UI rendering; Node/Express for asynchronous non-blocking event-loop scalability; and MongoDB for flexible JSON-like document modeling.`,
        securityMeasures: [
          'Bcrypt Password Hashing: Uses 10 salt rounds to eliminate plaintext password storage.',
          'Stateless JWT Authorization: Verified cryptographically on protected API endpoints.',
          'Static Secret Detection: Regex scanners preventing hardcoded API tokens from leaking.',
          'Asynchronous Error Boundary: Wraps async operations to prevent server unhandled promise crashes.'
        ],
        keyApiEndpoints: [
          { method: 'POST', endpoint: '/api/auth/register', purpose: 'Registers new student/developer account.' },
          { method: 'POST', endpoint: '/api/auth/login', purpose: 'Authenticates user and returns signed JWT token.' },
          { method: 'POST', endpoint: '/api/projects/analyze', purpose: 'Performs AST code audit on uploaded repository.' },
          { method: 'POST', endpoint: '/api/projects/:id/report', purpose: 'Saves customized student project report.' }
        ]
      },
      chapter6_testing: {
        testingStrategy: `Testing encompasses unit tests for algorithmic calculations, integration testing for API communication, and black-box verification for UI components.`,
        testCases: [
          { id: 'TC-01', module: 'Auth', description: 'Valid student user login', expected: 'HTTP 200, JWT returned', actual: 'HTTP 200, JWT returned', status: 'PASS' },
          { id: 'TC-02', module: 'Ingestion', description: 'Upload repository ZIP archive', expected: 'HTTP 201, files parsed', actual: 'HTTP 201, files parsed', status: 'PASS' },
          { id: 'TC-03', module: 'Audit', description: 'Scan code for secret key leaks', expected: 'Critical alert flagged', actual: 'Critical alert flagged', status: 'PASS' },
          { id: 'TC-04', module: 'Report', description: 'Generate and print academic PDF', expected: 'Multi-page formal report', actual: 'Clean PDF rendered', status: 'PASS' }
        ],
        qualityAudit: `Static automated analysis awarded an Overall Health Score of ${ana?.scores?.codeQuality || 85}/100. Critical boundary validation and security mitigations were applied.`
      },
      chapter7_results: {
        projectOutcomes: `All functional and performance goals were fulfilled. The system achieved sub-second latency on standard queries and provides an intuitive, student-friendly interface for capstone project documentation.`,
        screenDescriptions: [
          'Dashboard: Real-time health gauges, metric distribution, and project management.',
          'Project Report Builder: Academic submission document editor with live preview and PDF generation.',
          'Architecture Viewer: Multi-tier interactive graph displaying client-server data flows.',
          'Code Review Inspector: Side-by-side patch diffs addressing identified code smells.'
        ]
      },
      chapter8_conclusion: {
        conclusion: `The project "${cleanTitle}" successfully provides a production-grade software platform backed by rigorous engineering practices. The solution meets all university project requirements, demonstrating modern full-stack development.`,
        futureScope: [
          'Automated CI/CD GitHub Actions integration for continuous project audits.',
          'Docker containerization and Kubernetes cluster deployment.',
          'Expansion of static code analysis to Python, Java, and Go repositories.'
        ]
      },
      references: [
        'Martin, Robert C. Clean Architecture: A Craftsman\'s Guide to Software Structure. Prentice Hall, 2017.',
        'IEEE Recommended Practice for Software Requirements Specifications (IEEE Std 830-1998).',
        'Fielding, Roy T. Architectural Styles and the Design of Network-based Software Architectures. 2000.',
        'OWASP Foundation. Top 10 Web Application Security Risks. 2021 Edition.',
        'MDN Web Docs. Mozilla Developer Network Standards for Modern Web Applications. 2024.'
      ]
    };
  }

  // Update deep nested state
  function updateField(path, value) {
    setReport((prev) => {
      const copy = JSON.parse(JSON.stringify(prev));
      const parts = path.split('.');
      let current = copy;
      for (let i = 0; i < parts.length - 1; i++) {
        current = current[parts[i]];
      }
      current[parts[parts.length - 1]] = value;
      // Auto cache locally
      localStorage.setItem(storageKey, JSON.stringify(copy));
      return copy;
    });
  }

  // Save report to backend
  async function handleSave() {
    if (!report) return;
    setSaving(true);
    setSaveSuccess(false);
    setError('');

    // Cache to localStorage
    localStorage.setItem(storageKey, JSON.stringify(report));

    try {
      if (token && project?._id) {
        await api.saveReport(project._id, report, token);
      }
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err) {
      setError(`Notice: Saved to browser storage (${err.message}).`);
    } finally {
      setSaving(false);
    }
  }

  // Regenerate report with AI
  async function handleRegenerate(customPrompt) {
    setRegenerating(true);
    setShowAiModal(false);
    setError('');

    try {
      if (token && project?._id) {
        const res = await api.regenerateReport(project._id, customPrompt, report?.meta, token);
        if (res.report) {
          setReport(res.report);
          localStorage.setItem(storageKey, JSON.stringify(res.report));
          setSaveSuccess(true);
          setTimeout(() => setSaveSuccess(false), 2500);
          return;
        }
      }
      // Local fallback regeneration
      const fresh = createLocalDefaultReport(project, analysis);
      if (customPrompt) {
        fresh.chapter1_intro.overview += `\n\n[Custom Focus]: ${customPrompt}`;
      }
      setReport(fresh);
      localStorage.setItem(storageKey, JSON.stringify(fresh));
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err) {
      setError(`Regeneration failed: ${err.message}`);
    } finally {
      setRegenerating(false);
    }
  }

  // Reset to original synthesis
  function handleReset() {
    if (!window.confirm('Reset this report to the original AI-generated content? Your custom edits will be replaced.')) return;
    const fresh = createLocalDefaultReport(project, analysis);
    setReport(fresh);
    localStorage.setItem(storageKey, JSON.stringify(fresh));
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  }

  if (loading || !report) {
    return (
      <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
        <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-8 text-center text-[#8b949e]">
          <div className="w-8 h-8 border-2 border-[#38bdf8] border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          Generating final year project report documentation…
        </div>
      </div>
    );
  }

  const { meta, frontMatter, chapter1_intro, chapter2_literature, chapter3_srs, chapter4_architecture, chapter5_implementation, chapter6_testing, chapter7_results, chapter8_conclusion, references } = report;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col overflow-hidden">
      {/* TOP CONTROLS & HEADER (Never printed) */}
      <div className="no-print bg-[#161b22] border-b border-[#30363d] px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4 flex-wrap z-20">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 via-blue-500 to-teal-400 text-white flex items-center justify-center font-bold text-lg shadow-sm">
            🎓
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-extrabold text-white tracking-tight">
                Final Year Project Report Generator
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-950/80 border border-blue-800 font-bold text-blue-300 font-mono">
                University Submission Ready
              </span>
            </div>
            <p className="text-xs text-[#8b949e]">
              {meta.title} • Fully editable multi-chapter report with university cover page & PDF export
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Mode Switcher */}
          <div className="bg-[#0d1117] border border-[#30363d] p-1 rounded-xl flex items-center gap-1 text-xs font-bold">
            <button
              onClick={() => setMode('preview')}
              className={`px-3 py-1.5 rounded-lg transition ${
                mode === 'preview' ? 'bg-[#2563eb] text-white shadow-sm' : 'text-[#8b949e] hover:text-white'
              }`}
            >
              📄 Document Preview
            </button>
            <button
              onClick={() => setMode('edit')}
              className={`px-3 py-1.5 rounded-lg transition ${
                mode === 'edit' ? 'bg-[#2563eb] text-white shadow-sm' : 'text-[#8b949e] hover:text-white'
              }`}
            >
              ✏️ Edit Report
            </button>
          </div>

          {/* Regenerate AI Button */}
          <button
            onClick={() => setShowAiModal(true)}
            disabled={regenerating}
            className="px-3 py-1.5 rounded-xl border border-indigo-500/50 bg-indigo-950/40 text-indigo-300 hover:bg-indigo-900/50 text-xs font-bold transition flex items-center gap-1.5 disabled:opacity-50"
            title="Regenerate or customize report sections with AI"
          >
            <span>{regenerating ? '⏳' : '✨'}</span>
            <span>{regenerating ? 'Regenerating…' : 'Regenerate with AI'}</span>
          </button>

          {/* Save Button */}
          <button
            onClick={handleSave}
            disabled={saving}
            className="px-3.5 py-1.5 rounded-xl bg-[#238636] hover:bg-[#2ea043] text-white text-xs font-bold transition shadow-sm flex items-center gap-1.5 disabled:opacity-50"
          >
            <span>{saving ? '💾' : saveSuccess ? '✓' : '💾'}</span>
            <span>{saving ? 'Saving…' : saveSuccess ? 'Saved!' : 'Save Edits'}</span>
          </button>

          {/* Download PDF Button */}
          <button
            onClick={() => window.print()}
            className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#4f46e5] to-[#2563eb] hover:from-[#4338ca] hover:to-[#1d4ed8] text-white text-xs font-bold transition shadow-sm flex items-center gap-2"
            title="Download full multi-page academic project report as PDF"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14 2 14 8 20 8" />
              <line x1="16" y1="13" x2="8" y2="13" />
              <line x1="16" y1="17" x2="8" y2="17" />
              <polyline points="10 9 9 9 8 9" />
            </svg>
            <span>Download PDF Report</span>
          </button>

          {/* Close Button */}
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#8b949e] hover:text-white hover:bg-[#30363d] transition text-base font-bold ml-1"
              title="Close report generator"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* ERROR NOTICE BAR */}
      {error && (
        <div className="no-print bg-amber-950/70 border-b border-amber-800 px-6 py-2 text-xs text-amber-300 flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError('')} className="text-amber-400 font-bold hover:underline">✕</button>
        </div>
      )}

      {/* MAIN CONTAINER */}
      <div className="flex-1 overflow-y-auto bg-slate-900/70 p-4 sm:p-6 flex justify-center">
        {mode === 'edit' ? (
          /* ==============================================================
             EDIT MODE INTERFACE (No-print)
             ============================================================== */
          <div className="no-print bg-[#161b22] border border-[#30363d] rounded-2xl max-w-4xl w-full p-6 shadow-2xl space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#21262d] flex-wrap gap-3">
              <div>
                <h3 className="text-lg font-bold text-white">Report Content & Metadata Editor</h3>
                <p className="text-xs text-[#8b949e]">
                  Modify student details, college parameters, objectives, requirements, and conclusions. Changes are autosaved.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleReset}
                  className="text-xs text-[#8b949e] hover:text-red-400 font-semibold px-2 py-1 rounded border border-[#30363d] hover:border-red-900 transition"
                >
                  ↺ Reset to Default
                </button>
                <button
                  onClick={() => setMode('preview')}
                  className="text-xs bg-[#2563eb] text-white font-bold px-3 py-1.5 rounded-lg hover:bg-[#1d4ed8] transition"
                >
                  View Formatted Preview →
                </button>
              </div>
            </div>

            {/* Chapter Tabs */}
            <div className="flex flex-wrap gap-1.5 border-b border-[#21262d] pb-2 text-xs font-semibold">
              {[
                { id: 'meta', label: '1. Cover & Student Info' },
                { id: 'frontMatter', label: '2. Certificates & Abstract' },
                { id: 'ch1', label: '3. Ch 1: Intro & Objectives' },
                { id: 'ch2', label: '4. Ch 2: Literature & Survey' },
                { id: 'ch3', label: '5. Ch 3: SRS & Requirements' },
                { id: 'ch4', label: '6. Ch 4: Architecture & Design' },
                { id: 'ch5', label: '7. Ch 5: Implementation' },
                { id: 'ch6', label: '8. Ch 6: Testing & Quality' },
                { id: 'ch7', label: '9. Ch 7: Results' },
                { id: 'ch8', label: '10. Ch 8: Conclusion & Refs' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-3 py-1.5 rounded-lg transition ${
                    activeTab === tab.id
                      ? 'bg-blue-950/80 text-[#38bdf8] border border-blue-800 font-bold'
                      : 'text-[#8b949e] hover:text-white hover:bg-[#21262d]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* TAB CONTENTS */}
            {/* 1. Meta / Cover Page Details */}
            {activeTab === 'meta' && (
              <div className="space-y-4 text-xs">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Project Title</label>
                    <input
                      type="text"
                      value={meta.title}
                      onChange={(e) => updateField('meta.title', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Degree / Course</label>
                    <input
                      type="text"
                      value={meta.degree}
                      onChange={(e) => updateField('meta.degree', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Student Name(s)</label>
                    <input
                      type="text"
                      value={meta.studentName}
                      onChange={(e) => updateField('meta.studentName', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Roll Number / USN</label>
                    <input
                      type="text"
                      value={meta.rollNo}
                      onChange={(e) => updateField('meta.rollNo', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Project Guide / Supervisor</label>
                    <input
                      type="text"
                      value={meta.guideName}
                      onChange={(e) => updateField('meta.guideName', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Department</label>
                    <input
                      type="text"
                      value={meta.department}
                      onChange={(e) => updateField('meta.department', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">College / Institute Name</label>
                    <input
                      type="text"
                      value={meta.collegeName}
                      onChange={(e) => updateField('meta.collegeName', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Affiliated University</label>
                    <input
                      type="text"
                      value={meta.university}
                      onChange={(e) => updateField('meta.university', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Academic Year</label>
                    <input
                      type="text"
                      value={meta.academicYear}
                      onChange={(e) => updateField('meta.academicYear', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Month & Year of Submission</label>
                    <input
                      type="text"
                      value={meta.submissionMonthYear}
                      onChange={(e) => updateField('meta.submissionMonthYear', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 2. Front Matter: Certificate & Abstract */}
            {activeTab === 'frontMatter' && (
              <div className="space-y-4 text-xs">
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Certificate Text</label>
                  <textarea
                    rows={4}
                    value={frontMatter.certificate}
                    onChange={(e) => updateField('frontMatter.certificate', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Student Declaration</label>
                  <textarea
                    rows={3}
                    value={frontMatter.declaration}
                    onChange={(e) => updateField('frontMatter.declaration', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Acknowledgement</label>
                  <textarea
                    rows={4}
                    value={frontMatter.acknowledgement}
                    onChange={(e) => updateField('frontMatter.acknowledgement', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Project Abstract</label>
                  <textarea
                    rows={5}
                    value={frontMatter.abstract}
                    onChange={(e) => updateField('frontMatter.abstract', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
              </div>
            )}

            {/* 3. Chapter 1: Intro */}
            {activeTab === 'ch1' && (
              <div className="space-y-4 text-xs">
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">1.1 Project Overview & Motivation</label>
                  <textarea
                    rows={4}
                    value={chapter1_intro.overview}
                    onChange={(e) => updateField('chapter1_intro.overview', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">1.2 Problem Statement</label>
                  <textarea
                    rows={4}
                    value={chapter1_intro.problemStatement}
                    onChange={(e) => updateField('chapter1_intro.problemStatement', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">1.3 Project Objectives (One per line)</label>
                  <textarea
                    rows={5}
                    value={(chapter1_intro.objectives || []).join('\n')}
                    onChange={(e) => updateField('chapter1_intro.objectives', e.target.value.split('\n').filter(Boolean))}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">1.4 Project Scope & Limitations</label>
                  <textarea
                    rows={3}
                    value={chapter1_intro.scope}
                    onChange={(e) => updateField('chapter1_intro.scope', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
              </div>
            )}

            {/* 4. Chapter 2: Literature Survey */}
            {activeTab === 'ch2' && (
              <div className="space-y-4 text-xs">
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">2.1 Literature Survey</label>
                  <textarea
                    rows={4}
                    value={chapter2_literature.literatureSurvey}
                    onChange={(e) => updateField('chapter2_literature.literatureSurvey', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">2.2 Limitations of Existing Systems</label>
                  <textarea
                    rows={4}
                    value={(chapter2_literature.existingSystemLimitations || []).join('\n')}
                    onChange={(e) => updateField('chapter2_literature.existingSystemLimitations', e.target.value.split('\n').filter(Boolean))}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">2.3 Proposed System Architecture</label>
                  <textarea
                    rows={4}
                    value={chapter2_literature.proposedSystem}
                    onChange={(e) => updateField('chapter2_literature.proposedSystem', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
              </div>
            )}

            {/* 5. Chapter 3: SRS */}
            {activeTab === 'ch3' && (
              <div className="space-y-4 text-xs">
                <div>
                  <div className="font-bold text-[#c9d1d9] mb-2 flex items-center justify-between">
                    <span>3.1 Functional Requirements</span>
                    <button
                      onClick={() => {
                        const current = chapter3_srs.functionalRequirements || [];
                        const nextId = `FR-0${current.length + 1}`;
                        updateField('chapter3_srs.functionalRequirements', [
                          ...current,
                          { id: nextId, name: 'New Functional Requirement', desc: 'Requirement details' }
                        ]);
                      }}
                      className="text-xs text-[#38bdf8] font-bold hover:underline"
                    >
                      + Add Requirement
                    </button>
                  </div>
                  <div className="space-y-2">
                    {(chapter3_srs.functionalRequirements || []).map((fr, idx) => (
                      <div key={idx} className="p-3 bg-[#0d1117] border border-[#30363d] rounded-xl grid sm:grid-cols-12 gap-2 items-center">
                        <input
                          type="text"
                          value={fr.id}
                          onChange={(e) => {
                            const updated = [...chapter3_srs.functionalRequirements];
                            updated[idx].id = e.target.value;
                            updateField('chapter3_srs.functionalRequirements', updated);
                          }}
                          className="sm:col-span-2 px-2 py-1 bg-[#161b22] border border-[#30363d] rounded text-white font-mono"
                        />
                        <input
                          type="text"
                          value={fr.name}
                          onChange={(e) => {
                            const updated = [...chapter3_srs.functionalRequirements];
                            updated[idx].name = e.target.value;
                            updateField('chapter3_srs.functionalRequirements', updated);
                          }}
                          className="sm:col-span-3 px-2 py-1 bg-[#161b22] border border-[#30363d] rounded text-white font-bold"
                        />
                        <input
                          type="text"
                          value={fr.desc}
                          onChange={(e) => {
                            const updated = [...chapter3_srs.functionalRequirements];
                            updated[idx].desc = e.target.value;
                            updateField('chapter3_srs.functionalRequirements', updated);
                          }}
                          className="sm:col-span-6 px-2 py-1 bg-[#161b22] border border-[#30363d] rounded text-[#c9d1d9]"
                        />
                        <button
                          onClick={() => {
                            const updated = chapter3_srs.functionalRequirements.filter((_, i) => i !== idx);
                            updateField('chapter3_srs.functionalRequirements', updated);
                          }}
                          className="sm:col-span-1 text-red-400 hover:text-red-300 text-center"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Hardware Requirements (Client)</label>
                    <textarea
                      rows={3}
                      value={chapter3_srs.hardwareRequirements?.client || ''}
                      onChange={(e) => updateField('chapter3_srs.hardwareRequirements.client', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-[#c9d1d9] block mb-1">Hardware Requirements (Server)</label>
                    <textarea
                      rows={3}
                      value={chapter3_srs.hardwareRequirements?.server || ''}
                      onChange={(e) => updateField('chapter3_srs.hardwareRequirements.server', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 6. Chapter 4 & 5: Architecture & Implementation */}
            {(activeTab === 'ch4' || activeTab === 'ch5') && (
              <div className="space-y-4 text-xs">
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Architecture Overview</label>
                  <textarea
                    rows={4}
                    value={chapter4_architecture.overview}
                    onChange={(e) => updateField('chapter4_architecture.overview', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Technology Stack Rationale</label>
                  <textarea
                    rows={4}
                    value={chapter5_implementation.techStackRationale}
                    onChange={(e) => updateField('chapter5_implementation.techStackRationale', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Security Measures & Defensive Architecture</label>
                  <textarea
                    rows={4}
                    value={(chapter5_implementation.securityMeasures || []).join('\n')}
                    onChange={(e) => updateField('chapter5_implementation.securityMeasures', e.target.value.split('\n').filter(Boolean))}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
              </div>
            )}

            {/* 7. Chapter 6: Testing */}
            {activeTab === 'ch6' && (
              <div className="space-y-4 text-xs">
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Testing Strategy & Methodology</label>
                  <textarea
                    rows={4}
                    value={chapter6_testing.testingStrategy}
                    onChange={(e) => updateField('chapter6_testing.testingStrategy', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Static Code Quality Findings</label>
                  <textarea
                    rows={3}
                    value={chapter6_testing.qualityAudit}
                    onChange={(e) => updateField('chapter6_testing.qualityAudit', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
              </div>
            )}

            {/* 8. Chapter 7 & 8: Results & Conclusion */}
            {(activeTab === 'ch7' || activeTab === 'ch8') && (
              <div className="space-y-4 text-xs">
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Project Outcomes</label>
                  <textarea
                    rows={4}
                    value={chapter7_results.projectOutcomes}
                    onChange={(e) => updateField('chapter7_results.projectOutcomes', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Project Conclusion</label>
                  <textarea
                    rows={4}
                    value={chapter8_conclusion.conclusion}
                    onChange={(e) => updateField('chapter8_conclusion.conclusion', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Future Scope & Enhancements (One per line)</label>
                  <textarea
                    rows={4}
                    value={(chapter8_conclusion.futureScope || []).join('\n')}
                    onChange={(e) => updateField('chapter8_conclusion.futureScope', e.target.value.split('\n').filter(Boolean))}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-[#c9d1d9] block mb-1">Academic References (One per line)</label>
                  <textarea
                    rows={4}
                    value={(references || []).join('\n')}
                    onChange={(e) => updateField('references', e.target.value.split('\n').filter(Boolean))}
                    className="w-full px-3 py-2 rounded-xl bg-[#0d1117] border border-[#30363d] text-white focus:border-[#38bdf8] outline-none font-mono"
                  />
                </div>
              </div>
            )}
          </div>
        ) : (
          /* ==============================================================
             DOCUMENT VIEW (What gets printed as PDF)
             ============================================================== */
          <div className="bg-white text-slate-900 rounded-xl shadow-2xl p-8 sm:p-14 max-w-4xl w-full border border-slate-300 font-serif leading-relaxed text-sm">
            {/* -------------------------------------------------------------
                PAGE 1: COVER PAGE
                ------------------------------------------------------------- */}
            <div className="academic-page-break flex flex-col justify-between items-center text-center min-h-[920px] py-10">
              <div className="w-full">
                <div className="text-xs uppercase font-sans tracking-[0.2em] text-slate-500 font-bold mb-6">
                  {meta.university}
                </div>
                <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight uppercase max-w-2xl mx-auto leading-snug">
                  {meta.title}
                </h1>
                <div className="mt-8 text-xs font-sans text-slate-600 uppercase tracking-wider font-semibold max-w-md mx-auto leading-relaxed">
                  A Project Report Submitted In Partial Fulfillment of the Requirements for the Award of the Degree of
                </div>
                <div className="mt-3 text-base font-bold text-slate-800 font-sans uppercase tracking-wide">
                  {meta.degree}
                </div>
              </div>

              {/* Emblematical Seal */}
              <div className="my-8">
                <div className="w-24 h-24 mx-auto rounded-full border-4 border-double border-indigo-700 flex items-center justify-center font-sans font-black text-2xl text-indigo-700 shadow-inner">
                  {meta.collegeName.slice(0, 3).toUpperCase()}
                </div>
              </div>

              {/* Student and Supervisor Section */}
              <div className="w-full grid grid-cols-2 gap-8 text-left font-sans text-xs px-6">
                <div>
                  <div className="text-slate-500 uppercase tracking-wider font-semibold text-[10px]">Submitted By:</div>
                  <div className="font-bold text-sm text-slate-900 mt-1">{meta.studentName}</div>
                  <div className="font-mono text-slate-700 mt-0.5">{meta.rollNo}</div>
                </div>
                <div className="text-right">
                  <div className="text-slate-500 uppercase tracking-wider font-semibold text-[10px]">Under the Guidance of:</div>
                  <div className="font-bold text-sm text-slate-900 mt-1">{meta.guideName}</div>
                  <div className="text-slate-700 mt-0.5">{meta.department}</div>
                </div>
              </div>

              {/* Footer College & Year */}
              <div className="w-full pt-8 border-t border-slate-300 font-sans text-xs text-slate-700">
                <div className="font-bold text-slate-900 uppercase tracking-wide">{meta.department}</div>
                <div className="font-semibold text-slate-800">{meta.collegeName}</div>
                <div className="text-slate-500 mt-1">{meta.submissionMonthYear} • Academic Year {meta.academicYear}</div>
              </div>
            </div>

            {/* -------------------------------------------------------------
                PAGE 2: CERTIFICATE OF AUTHENTICITY
                ------------------------------------------------------------- */}
            <div className="academic-page-break min-h-[920px] py-10 flex flex-col justify-between">
              <div>
                <div className="text-center mb-8">
                  <div className="text-xs font-sans uppercase tracking-widest text-slate-500 font-bold">{meta.collegeName}</div>
                  <div className="text-xs font-sans text-slate-600">{meta.department}</div>
                  <h2 className="text-2xl font-bold font-sans text-slate-900 tracking-tight mt-6 uppercase border-b-2 border-slate-800 pb-2 inline-block">
                    Certificate of Original Work
                  </h2>
                </div>

                <div className="text-justify leading-loose text-sm text-slate-800 my-8">
                  {frontMatter.certificate}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-6 text-center font-sans text-xs pt-16">
                <div>
                  <div className="border-t border-slate-400 pt-2 font-bold text-slate-800">Signature of Guide</div>
                  <div className="text-[10px] text-slate-500">({meta.guideName})</div>
                </div>
                <div>
                  <div className="border-t border-slate-400 pt-2 font-bold text-slate-800">Head of Department</div>
                  <div className="text-[10px] text-slate-500">({meta.department})</div>
                </div>
                <div>
                  <div className="border-t border-slate-400 pt-2 font-bold text-slate-800">External Examiner</div>
                  <div className="text-[10px] text-slate-500">Valuation Board</div>
                </div>
              </div>
            </div>

            {/* -------------------------------------------------------------
                PAGE 3: DECLARATION & ACKNOWLEDGEMENT
                ------------------------------------------------------------- */}
            <div className="academic-page-break min-h-[920px] py-10 space-y-12">
              <div>
                <h2 className="text-xl font-bold font-sans text-slate-900 uppercase tracking-tight border-b border-slate-300 pb-2 mb-4">
                  Candidate Declaration
                </h2>
                <div className="text-justify leading-relaxed text-sm text-slate-800">
                  {frontMatter.declaration}
                </div>
                <div className="mt-8 text-right font-sans text-xs">
                  <div className="font-bold text-slate-900">{meta.studentName}</div>
                  <div className="text-slate-600 font-mono">{meta.rollNo}</div>
                </div>
              </div>

              <div className="pt-6">
                <h2 className="text-xl font-bold font-sans text-slate-900 uppercase tracking-tight border-b border-slate-300 pb-2 mb-4">
                  Acknowledgement
                </h2>
                <div className="text-justify leading-relaxed text-sm text-slate-800 whitespace-pre-line">
                  {frontMatter.acknowledgement}
                </div>
              </div>
            </div>

            {/* -------------------------------------------------------------
                PAGE 4: ABSTRACT & TABLE OF CONTENTS
                ------------------------------------------------------------- */}
            <div className="academic-page-break min-h-[920px] py-10 space-y-10">
              <div>
                <h2 className="text-xl font-bold font-sans text-slate-900 uppercase tracking-tight border-b border-slate-300 pb-2 mb-4">
                  Abstract
                </h2>
                <div className="text-justify leading-relaxed text-sm text-slate-800">
                  {frontMatter.abstract}
                </div>
                <div className="mt-4 pt-3 border-t border-slate-200 font-sans text-xs">
                  <span className="font-bold text-slate-700">Keywords: </span>
                  <span className="text-slate-600">{(frontMatter.keywords || []).join(', ')}</span>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-bold font-sans text-slate-900 uppercase tracking-tight border-b border-slate-300 pb-2 mb-4">
                  Table of Contents
                </h2>
                <div className="font-sans text-xs space-y-2 text-slate-700">
                  <div className="flex justify-between border-b border-dotted border-slate-300 pb-1">
                    <span className="font-bold">Chapter 1: Introduction, Problem Statement & Objectives</span>
                    <span className="font-mono">1</span>
                  </div>
                  <div className="flex justify-between border-b border-dotted border-slate-300 pb-1">
                    <span className="font-bold">Chapter 2: Literature Survey & System Study</span>
                    <span className="font-mono">3</span>
                  </div>
                  <div className="flex justify-between border-b border-dotted border-slate-300 pb-1">
                    <span className="font-bold">Chapter 3: System Requirements Specification (SRS)</span>
                    <span className="font-mono">5</span>
                  </div>
                  <div className="flex justify-between border-b border-dotted border-slate-300 pb-1">
                    <span className="font-bold">Chapter 4: System Architecture & Module Design</span>
                    <span className="font-mono">7</span>
                  </div>
                  <div className="flex justify-between border-b border-dotted border-slate-300 pb-1">
                    <span className="font-bold">Chapter 5: Implementation Highlights & Defensive Engineering</span>
                    <span className="font-mono">9</span>
                  </div>
                  <div className="flex justify-between border-b border-dotted border-slate-300 pb-1">
                    <span className="font-bold">Chapter 6: Software Testing & Quality Assurance</span>
                    <span className="font-mono">12</span>
                  </div>
                  <div className="flex justify-between border-b border-dotted border-slate-300 pb-1">
                    <span className="font-bold">Chapter 7: Results, Outputs & Performance Metrics</span>
                    <span className="font-mono">14</span>
                  </div>
                  <div className="flex justify-between border-b border-dotted border-slate-300 pb-1">
                    <span className="font-bold">Chapter 8: Conclusion & Future Scope</span>
                    <span className="font-mono">16</span>
                  </div>
                  <div className="flex justify-between border-b border-dotted border-slate-300 pb-1">
                    <span className="font-bold">References & Academic Bibliography</span>
                    <span className="font-mono">17</span>
                  </div>
                </div>
              </div>
            </div>

            {/* -------------------------------------------------------------
                CHAPTER 1: INTRODUCTION
                ------------------------------------------------------------- */}
            <div className="academic-page-break min-h-[920px] py-10 space-y-6">
              <div className="border-b-2 border-indigo-700 pb-2 mb-6">
                <div className="text-xs font-sans uppercase tracking-widest text-indigo-700 font-bold">Chapter 1</div>
                <h2 className="text-2xl font-bold font-sans text-slate-900 tracking-tight uppercase">
                  Introduction
                </h2>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">1.1 Project Overview</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter1_intro.overview}
                </p>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">1.2 Problem Statement</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter1_intro.problemStatement}
                </p>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">1.3 Objectives of the Project</h3>
                <ul className="list-disc pl-5 space-y-1.5 text-sm text-slate-800">
                  {(chapter1_intro.objectives || []).map((obj, i) => (
                    <li key={i}>{obj}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">1.4 Project Scope</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter1_intro.scope}
                </p>
              </div>
            </div>

            {/* -------------------------------------------------------------
                CHAPTER 2: LITERATURE SURVEY
                ------------------------------------------------------------- */}
            <div className="academic-page-break min-h-[920px] py-10 space-y-6">
              <div className="border-b-2 border-indigo-700 pb-2 mb-6">
                <div className="text-xs font-sans uppercase tracking-widest text-indigo-700 font-bold">Chapter 2</div>
                <h2 className="text-2xl font-bold font-sans text-slate-900 tracking-tight uppercase">
                  Literature Survey & System Study
                </h2>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">2.1 Literature Survey</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter2_literature.literatureSurvey}
                </p>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">2.2 Deficiencies in Existing Systems</h3>
                <ul className="list-disc pl-5 space-y-1.5 text-sm text-slate-800">
                  {(chapter2_literature.existingSystemLimitations || []).map((lim, i) => (
                    <li key={i}>{lim}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">2.3 Proposed System Architecture</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter2_literature.proposedSystem}
                </p>
              </div>

              {chapter2_literature.comparisonMatrix?.length > 0 && (
                <div>
                  <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">2.4 Comparison Matrix</h3>
                  <table className="w-full text-left font-sans text-xs border border-slate-300">
                    <thead className="bg-slate-100 border-b border-slate-300">
                      <tr>
                        <th className="p-2 font-bold text-slate-700">Feature</th>
                        <th className="p-2 font-bold text-slate-700">Existing Approach</th>
                        <th className="p-2 font-bold text-indigo-800 bg-indigo-50">Proposed System ({meta.title})</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {chapter2_literature.comparisonMatrix.map((row, i) => (
                        <tr key={i}>
                          <td className="p-2 font-semibold text-slate-800">{row.feature}</td>
                          <td className="p-2 text-slate-600">{row.existing}</td>
                          <td className="p-2 text-slate-900 font-medium bg-indigo-50/40">{row.proposed}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* -------------------------------------------------------------
                CHAPTER 3: SYSTEM REQUIREMENTS SPECIFICATION (SRS)
                ------------------------------------------------------------- */}
            <div className="academic-page-break min-h-[920px] py-10 space-y-6">
              <div className="border-b-2 border-indigo-700 pb-2 mb-6">
                <div className="text-xs font-sans uppercase tracking-widest text-indigo-700 font-bold">Chapter 3</div>
                <h2 className="text-2xl font-bold font-sans text-slate-900 tracking-tight uppercase">
                  System Requirements Specification (SRS)
                </h2>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">3.1 Functional Requirements</h3>
                <div className="border border-slate-300 rounded-lg overflow-hidden font-sans text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 border-b border-slate-300">
                      <tr>
                        <th className="p-2.5 font-bold text-slate-700 w-20">Req ID</th>
                        <th className="p-2.5 font-bold text-slate-700 w-44">Module Name</th>
                        <th className="p-2.5 font-bold text-slate-700">Specification Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {(chapter3_srs.functionalRequirements || []).map((fr) => (
                        <tr key={fr.id}>
                          <td className="p-2 font-mono font-bold text-indigo-700">{fr.id}</td>
                          <td className="p-2 font-semibold text-slate-800">{fr.name}</td>
                          <td className="p-2 text-slate-600 leading-normal">{fr.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">3.2 Non-Functional Requirements</h3>
                <div className="grid sm:grid-cols-3 gap-3 font-sans text-xs">
                  {(chapter3_srs.nonFunctionalRequirements || []).map((nfr, i) => (
                    <div key={i} className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                      <div className="font-bold text-indigo-700 uppercase text-[10px]">{nfr.category}</div>
                      <div className="text-slate-700 mt-1">{nfr.desc}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4 font-sans text-xs">
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                  <div className="font-bold text-slate-800 mb-1">Hardware Specification</div>
                  <div className="text-slate-600 mb-1"><span className="font-semibold text-slate-700">Client:</span> {chapter3_srs.hardwareRequirements?.client}</div>
                  <div className="text-slate-600"><span className="font-semibold text-slate-700">Server:</span> {chapter3_srs.hardwareRequirements?.server}</div>
                </div>
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                  <div className="font-bold text-slate-800 mb-1">Software Specification</div>
                  <div className="text-slate-600"><span className="font-semibold text-slate-700">OS:</span> {chapter3_srs.softwareRequirements?.operatingSystem}</div>
                  <div className="text-slate-600"><span className="font-semibold text-slate-700">Runtime:</span> {chapter3_srs.softwareRequirements?.runtime}</div>
                  <div className="text-slate-600"><span className="font-semibold text-slate-700">Database:</span> {chapter3_srs.softwareRequirements?.database}</div>
                  <div className="text-slate-600"><span className="font-semibold text-slate-700">Stack:</span> {chapter3_srs.softwareRequirements?.frontendFramework} • {chapter3_srs.softwareRequirements?.backendFramework}</div>
                </div>
              </div>
            </div>

            {/* -------------------------------------------------------------
                CHAPTER 4: SYSTEM ARCHITECTURE & DESIGN
                ------------------------------------------------------------- */}
            <div className="academic-page-break min-h-[920px] py-10 space-y-6">
              <div className="border-b-2 border-indigo-700 pb-2 mb-6">
                <div className="text-xs font-sans uppercase tracking-widest text-indigo-700 font-bold">Chapter 4</div>
                <h2 className="text-2xl font-bold font-sans text-slate-900 tracking-tight uppercase">
                  System Architecture & Design
                </h2>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">4.1 Architecture Overview</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter4_architecture.overview}
                </p>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">4.2 Module Decomposition</h3>
                <div className="space-y-2.5 font-sans text-xs">
                  {(chapter4_architecture.modules || []).map((mod, i) => (
                    <div key={i} className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                      <div className="font-bold text-indigo-800">{mod.name}</div>
                      <div className="text-slate-600 mt-0.5">{mod.desc}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">4.3 Database Schema & Data Models</h3>
                <div className="border border-slate-300 rounded-lg overflow-hidden font-sans text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 border-b border-slate-300">
                      <tr>
                        <th className="p-2 font-bold text-slate-700">Collection</th>
                        <th className="p-2 font-bold text-slate-700">Key Fields</th>
                        <th className="p-2 font-bold text-slate-700">Purpose</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {(chapter4_architecture.databaseSchema || []).map((schema, i) => (
                        <tr key={i}>
                          <td className="p-2 font-mono font-bold text-indigo-700">{schema.collection}</td>
                          <td className="p-2 font-mono text-[11px] text-slate-700">{schema.fields}</td>
                          <td className="p-2 text-slate-600">{schema.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">4.4 Data Flow & Request Lifecycle</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line font-sans text-xs bg-slate-50 p-3.5 border border-slate-200 rounded-lg">
                  {chapter4_architecture.dataFlow}
                </p>
              </div>
            </div>

            {/* -------------------------------------------------------------
                CHAPTER 5: IMPLEMENTATION DETAILS
                ------------------------------------------------------------- */}
            <div className="academic-page-break min-h-[920px] py-10 space-y-6">
              <div className="border-b-2 border-indigo-700 pb-2 mb-6">
                <div className="text-xs font-sans uppercase tracking-widest text-indigo-700 font-bold">Chapter 5</div>
                <h2 className="text-2xl font-bold font-sans text-slate-900 tracking-tight uppercase">
                  Implementation Highlights
                </h2>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">5.1 Technology Stack Rationale</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter5_implementation.techStackRationale}
                </p>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">5.2 Security Mechanisms Implemented</h3>
                <ul className="list-disc pl-5 space-y-1.5 text-sm text-slate-800">
                  {(chapter5_implementation.securityMeasures || []).map((sec, i) => (
                    <li key={i}>{sec}</li>
                  ))}
                </ul>
              </div>

              {chapter5_implementation.keyApiEndpoints?.length > 0 && (
                <div>
                  <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">5.3 REST API Endpoints</h3>
                  <div className="border border-slate-300 rounded-lg overflow-hidden font-sans text-xs">
                    <table className="w-full text-left">
                      <thead className="bg-slate-100 border-b border-slate-300">
                        <tr>
                          <th className="p-2 font-bold text-slate-700 w-24">Method</th>
                          <th className="p-2 font-bold text-slate-700 w-56">Endpoint</th>
                          <th className="p-2 font-bold text-slate-700">Handler Purpose</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {chapter5_implementation.keyApiEndpoints.map((ep, i) => (
                          <tr key={i}>
                            <td className="p-2 font-mono font-bold text-emerald-700">{ep.method}</td>
                            <td className="p-2 font-mono text-slate-800">{ep.endpoint}</td>
                            <td className="p-2 text-slate-600">{ep.purpose}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* -------------------------------------------------------------
                CHAPTER 6: SOFTWARE TESTING & QUALITY ASSURANCE
                ------------------------------------------------------------- */}
            <div className="academic-page-break min-h-[920px] py-10 space-y-6">
              <div className="border-b-2 border-indigo-700 pb-2 mb-6">
                <div className="text-xs font-sans uppercase tracking-widest text-indigo-700 font-bold">Chapter 6</div>
                <h2 className="text-2xl font-bold font-sans text-slate-900 tracking-tight uppercase">
                  Software Testing & Quality Assurance
                </h2>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">6.1 Testing Strategy</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter6_testing.testingStrategy}
                </p>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">6.2 Empirical Test Execution Cases</h3>
                <div className="border border-slate-300 rounded-lg overflow-hidden font-sans text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 border-b border-slate-300">
                      <tr>
                        <th className="p-2 font-bold text-slate-700 w-16">ID</th>
                        <th className="p-2 font-bold text-slate-700 w-20">Module</th>
                        <th className="p-2 font-bold text-slate-700">Input Condition</th>
                        <th className="p-2 font-bold text-slate-700">Expected Result</th>
                        <th className="p-2 font-bold text-slate-700 w-16 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {(chapter6_testing.testCases || []).map((tc) => (
                        <tr key={tc.id}>
                          <td className="p-2 font-mono font-bold text-indigo-700">{tc.id}</td>
                          <td className="p-2 font-semibold text-slate-700">{tc.module}</td>
                          <td className="p-2 text-slate-600">{tc.description}</td>
                          <td className="p-2 text-slate-600">{tc.expected}</td>
                          <td className="p-2 text-center">
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                              {tc.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">6.3 Code Quality & Security Audit Findings</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter6_testing.qualityAudit}
                </p>
              </div>
            </div>

            {/* -------------------------------------------------------------
                CHAPTER 7 & 8: RESULTS, CONCLUSION & REFERENCES
                ------------------------------------------------------------- */}
            <div className="academic-page-break min-h-[920px] py-10 space-y-6">
              <div className="border-b-2 border-indigo-700 pb-2 mb-6">
                <div className="text-xs font-sans uppercase tracking-widest text-indigo-700 font-bold">Chapter 7 & 8</div>
                <h2 className="text-2xl font-bold font-sans text-slate-900 tracking-tight uppercase">
                  Results, Conclusion & References
                </h2>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">7.1 Project Outcomes & Evaluation</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter7_results.projectOutcomes}
                </p>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">8.1 Conclusion</h3>
                <p className="text-justify text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                  {chapter8_conclusion.conclusion}
                </p>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-2">8.2 Scope for Future Enhancements</h3>
                <ul className="list-disc pl-5 space-y-1.5 text-sm text-slate-800">
                  {(chapter8_conclusion.futureScope || []).map((item, i) => (
                    <li key={i}>{item}</li>
                  ))}
                </ul>
              </div>

              <div className="pt-6 border-t border-slate-300">
                <h3 className="font-sans font-bold text-sm text-slate-900 uppercase mb-3">References & Academic Bibliography</h3>
                <ol className="list-decimal pl-5 space-y-1 text-xs text-slate-700 font-sans">
                  {(references || []).map((ref, i) => (
                    <li key={i}>{ref}</li>
                  ))}
                </ol>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* AI REGENERATE MODAL PROMPT */}
      {showAiModal && (
        <div className="no-print fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#161b22] border border-[#30363d] rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">✨</span>
                <h3 className="font-bold text-white text-base">Regenerate Project Report</h3>
              </div>
              <button
                onClick={() => setShowAiModal(false)}
                className="text-[#8b949e] hover:text-white text-sm"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-[#8b949e] leading-relaxed">
              GitInsight AI will analyze your codebase files, architecture, and metrics to re-synthesize high-quality academic chapters. Provide optional custom instructions below:
            </p>
            <textarea
              rows={4}
              placeholder="e.g. Focus on microservices and cloud scalability, or make it suitable for an M.Tech Capstone thesis..."
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-[#0d1117] border border-[#30363d] text-white text-xs placeholder-[#8b949e] focus:border-[#38bdf8] outline-none"
            />
            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                onClick={() => setShowAiModal(false)}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold text-[#8b949e] hover:text-white hover:bg-[#21262d] transition"
              >
                Cancel
              </button>
              <button
                onClick={() => handleRegenerate(aiPrompt.trim())}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#2563eb] text-white hover:bg-[#1d4ed8] shadow-sm transition"
              >
                Regenerate Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

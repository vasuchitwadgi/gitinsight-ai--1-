import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, token, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="no-print border-b border-[#30363d] bg-[#161b22]/90 backdrop-blur sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Left: Brand Logo */}
        <div className="flex items-center gap-5">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-gradient-to-br from-[#6366f1] via-[#3b82f6] to-[#06b6d4] text-white shadow-sm group-hover:scale-105 transition-transform">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2L2 7l10 5 10-5-10-5z" />
                <path d="M2 17l10 5 10-5" />
                <path d="M2 12l10 5 10-5" />
              </svg>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-white text-lg tracking-tight">GitInsight<span className="text-[#38bdf8]">.AI</span></span>
              <span className="hidden sm:inline-block text-[10px] uppercase font-bold font-mono px-2 py-0.5 rounded-full bg-[#1f2937] text-[#38bdf8] border border-[#374151]">
                Analysis Platform
              </span>
            </div>
          </Link>
        </div>

        {/* Right: Actions & User Info */}
        {token && (
          <div className="flex items-center gap-3 text-sm">
            <Link
              to="/analyze"
              className="px-4 py-2 rounded-xl font-bold text-xs bg-gradient-to-r from-[#4f46e5] to-[#2563eb] text-white hover:from-[#4338ca] hover:to-[#1d4ed8] shadow-sm hover:shadow-indigo-500/20 transition flex items-center gap-2"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M12 5v14M5 12h14" />
              </svg>
              <span>Run Analysis</span>
            </Link>

            <div className="hidden sm:flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-[#21262d] border border-[#30363d] text-xs font-medium text-[#c9d1d9]">
              <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-indigo-500 to-teal-400 flex items-center justify-center text-white text-[11px] font-bold">
                {(user?.name || 'Dev')[0].toUpperCase()}
              </div>
              <span className="font-semibold">{user?.name || 'Developer'}</span>
            </div>

            <button
              onClick={() => { logout(); navigate('/login'); }}
              className="px-3 py-1.5 rounded-xl border border-[#30363d] hover:border-[#484f58] text-xs font-semibold text-[#8b949e] hover:text-white hover:bg-[#21262d] transition"
            >
              Sign out
            </button>
          </div>
        )}
      </div>
    </header>
  );
}

import { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../api/client.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('gi_token'));
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) { setLoading(false); return; }
    api.me(token)
      .then((res) => setUser(res.user))
      .catch(() => { setToken(null); localStorage.removeItem('gi_token'); })
      .finally(() => setLoading(false));
  }, [token]);

  function loginWith(token, user) {
    localStorage.setItem('gi_token', token);
    setToken(token);
    setUser(user);
  }

  function logout() {
    localStorage.removeItem('gi_token');
    setToken(null);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ token, user, loading, loginWith, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);

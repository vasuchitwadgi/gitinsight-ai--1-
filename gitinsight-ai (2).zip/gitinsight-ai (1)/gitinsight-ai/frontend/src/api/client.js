const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

async function request(path, { method = 'GET', body, token } = {}) {
  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || 'Request failed.');
  return data;
}

async function analyze({ githubUrl, manualText, provider, zipFile }, token) {
  // Use multipart form data when a ZIP is attached; plain JSON otherwise.
  if (zipFile) {
    const form = new FormData();
    if (githubUrl) form.append('githubUrl', githubUrl);
    if (manualText) form.append('manualText', manualText);
    if (provider) form.append('provider', provider);
    form.append('projectZip', zipFile);

    const res = await fetch(`${API_URL}/projects/analyze`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: form
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.message || 'Request failed.');
    return data;
  }
  return request('/projects/analyze', { method: 'POST', body: { githubUrl, manualText, provider }, token });
}

export const api = {
  register: (payload) => request('/auth/register', { method: 'POST', body: payload }),
  login: (payload) => request('/auth/login', { method: 'POST', body: payload }),
  me: (token) => request('/auth/me', { token }),
  analyze,
  listProjects: (token) => request('/projects', { token }),
  getProject: (id, token) => request(`/projects/${id}`, { token }),
  deleteProject: (id, token) => request(`/projects/${id}`, { method: 'DELETE', token }),
  compareProjects: (ids, token) => request(`/projects/compare?ids=${ids.join(',')}`, { token }),
  chat: (id, message, token) => request(`/projects/${id}/chat`, { method: 'POST', body: { message }, token }),
  getReport: (id, token) => request(`/projects/${id}/report`, { token }),
  saveReport: (id, report, token) => request(`/projects/${id}/report`, { method: 'POST', body: { report }, token }),
  regenerateReport: (id, prompt, studentMeta, token) => request(`/projects/${id}/report/regenerate`, { method: 'POST', body: { prompt, studentMeta }, token })
};
